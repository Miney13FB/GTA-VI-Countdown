package com.gta6.countdown

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import java.util.Random
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Fuegos artificiales con los colores del logo. Reutiliza arrays (sin reservas) y se apaga solo al terminar. */
class CelebrationView(context: Context) : View(context) {

    private val d = resources.displayMetrics.density
    private val n = 260
    private val px = FloatArray(n)
    private val py = FloatArray(n)
    private val vx = FloatArray(n)
    private val vy = FloatArray(n)
    private val life = FloatArray(n)
    private val maxLife = FloatArray(n)
    private val size = FloatArray(n)
    private val col = IntArray(n)
    private var next = 0
    private var pending = 0
    private var last = 0L
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = Random()
    private val colors = intArrayOf(
        Color.parseColor("#3D5AFE"), Color.parseColor("#B52DD6"), Color.parseColor("#FF3C78"),
        Color.parseColor("#FF7A2F"), Color.parseColor("#FFD36B"), Color.WHITE
    )

    fun play() {
        for (k in 0 until 4) {
            pending++
            postDelayed({ burst() }, k * 550L)
        }
        last = 0L
        postInvalidateOnAnimation()
    }

    private fun burst() {
        pending--
        val cx = width * (0.2f + 0.6f * rnd.nextFloat())
        val cy = height * (0.15f + 0.3f * rnd.nextFloat())
        val c = colors[rnd.nextInt(colors.size)]
        for (i in 0 until 60) {
            val k = next
            next = (next + 1) % n
            val a = rnd.nextFloat() * 6.2832f
            val sp = (120f + 300f * rnd.nextFloat()) * d
            px[k] = cx
            py[k] = cy
            vx[k] = cos(a) * sp
            vy[k] = sin(a) * sp
            maxLife[k] = 1.4f + rnd.nextFloat()
            life[k] = maxLife[k]
            size[k] = (2f + 2.5f * rnd.nextFloat()) * d
            col[k] = if (rnd.nextFloat() < 0.7f) c else colors[rnd.nextInt(colors.size)]
        }
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else min(0.05f, (now - last) / 1e9f)
        last = now
        var alive = false
        val drag = 1f - 1.2f * dt
        for (i in 0 until n) {
            if (life[i] <= 0f) continue
            life[i] -= dt
            if (life[i] <= 0f) continue
            alive = true
            vy[i] += 380f * d * dt
            vx[i] *= drag
            vy[i] *= drag
            px[i] += vx[i] * dt
            py[i] += vy[i] * dt
            val f = life[i] / maxLife[i]
            paint.color = col[i]
            paint.alpha = (255 * min(1f, f * 1.6f)).toInt()
            canvas.drawCircle(px[i], py[i], size[i] * (0.4f + 0.6f * f), paint)
        }
        if (alive || pending > 0) postInvalidateOnAnimation() else last = 0L
    }
}
