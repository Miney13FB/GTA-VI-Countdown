package com.gta6.countdown

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.app.Activity
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.animation.ValueAnimator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private class Card(
        val target: Long,
        val doneText: String,
        val numbers: List<TextView>,
        val status: TextView
    ) {
        var doneShown = false
        var first = true
    }

    private val handler = Handler(Looper.getMainLooper())
    private val cards = mutableListOf<Card>()
    private val cardViews = mutableListOf<View>()

    private val tick = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            for (c in cards) {
                val rem = c.target - now
                if (rem <= 0) {
                    c.numbers.forEach { setNum(it, "00", !c.first) }
                    if (!c.doneShown) {
                        c.doneShown = true
                        c.status.text = c.doneText
                        ObjectAnimator.ofFloat(c.status, "alpha", 1f, 0.35f).apply {
                            duration = 700
                            repeatCount = ValueAnimator.INFINITE
                            repeatMode = ValueAnimator.REVERSE
                            start()
                        }
                    }
                } else {
                    val s = rem / 1000
                    val v = listOf(s / 86400, (s % 86400) / 3600, (s % 3600) / 60, s % 60)
                    v.forEachIndexed { i, x -> setNum(c.numbers[i], "%02d".format(x), !c.first) }
                }
                c.first = false
            }
            handler.postDelayed(this, 1000 - (System.currentTimeMillis() % 1000) + 5)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun setNum(tv: TextView, t: String, animate: Boolean) {
        if (tv.text.toString() == t) return
        tv.text = t
        if (animate) {
            tv.alpha = 0.3f
            tv.translationY = -dp(10).toFloat()
            tv.animate().alpha(1f).translationY(0f).setDuration(280)
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun buildCard(title: String, subtitle: String, target: Long, doneText: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable().apply {
                setColor(Color.argb(105, 18, 4, 36))
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), Color.argb(120, 255, 150, 210))
            }
            isClickable = true
        }
        box.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(120).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
            }
            false
        }

        box.addView(text(title, 18f, Color.WHITE, true).apply { letterSpacing = 0.08f })
        box.addView(text(subtitle, 12f, Color.parseColor("#FFD7A8")))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(6))
        }
        val numbers = mutableListOf<TextView>()
        listOf("DÍAS", "HORAS", "MIN", "SEG").forEach { label ->
            val unit = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(10), dp(4), dp(8))
                background = GradientDrawable().apply {
                    setColor(Color.argb(120, 0, 0, 0))
                    cornerRadius = dp(14).toFloat()
                }
            }
            val n = text("00", 32f, Color.WHITE, true).apply { fontFeatureSettings = "tnum" }
            numbers.add(n)
            unit.addView(n)
            unit.addView(text(label, 10f, Color.parseColor("#FFB4D8")))
            row.addView(unit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(4), 0, dp(4), 0)
            })
        }
        box.addView(row)
        val status = text("", 14f, Color.WHITE, true)
        box.addView(status)
        cards.add(Card(target, doneText, numbers, status))
        cardViews.add(box)
        return box
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }

        // Cabecera
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        header.addView(text("GRAND THEFT AUTO", 14f, Color.parseColor("#FFD7A8"), true).apply {
            letterSpacing = 0.3f
        })
        val vi = text("VI", 84f, Color.WHITE, true).apply {
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            letterSpacing = 0.05f
        }
        vi.post {
            vi.paint.shader = LinearGradient(
                0f, 0f, 0f, vi.height.toFloat(),
                Color.parseColor("#FFD36B"), Color.parseColor("#FF4FA3"), Shader.TileMode.CLAMP
            )
            vi.invalidate()
        }
        header.addView(vi)
        header.addView(text("Cuenta atrás · hora de España", 13f, Color.parseColor("#FFD7A8")))
        content.addView(header)

        val lp = { LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) } }
        content.addView(
            buildCard("SALIDA DEL JUEGO", "19 nov 2026 · 00:00 (España)", Targets.LAUNCH, "¡YA DISPONIBLE!"), lp()
        )
        content.addView(
            buildCard("PREDESCARGA", "10 nov 2026 · 00:00 (España)", Targets.PREDOWNLOAD, "¡PREDESCARGA ABIERTA!"), lp()
        )
        val footer = text(
            "App no oficial hecha por fans. No afiliada a Rockstar Games ni Take-Two.", 11f,
            Color.argb(170, 255, 255, 255)
        )
        content.addView(footer, lp())

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(content)
        }
        val root = FrameLayout(this)
        root.addView(SunsetView(this), FrameLayout.LayoutParams(-1, -1))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        // Edge-to-edge (Android 15/16)
        root.setOnApplyWindowInsetsListener { _, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val b = insets.getInsets(WindowInsets.Type.systemBars())
                scroll.setPadding(b.left, b.top, b.right, b.bottom)
            } else {
                @Suppress("DEPRECATION")
                scroll.setPadding(
                    insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                )
            }
            insets
        }

        // Animaciones de entrada
        header.alpha = 0f
        header.scaleX = 0.8f
        header.scaleY = 0.8f
        header.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(800)
            .setInterpolator(OvershootInterpolator(1.3f)).start()

        ObjectAnimator.ofPropertyValuesHolder(
            vi,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.05f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.05f)
        ).apply {
            duration = 1800
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            startDelay = 900
            start()
        }

        cardViews.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = dp(60).toFloat()
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(350L + i * 220L).setDuration(650)
                .setInterpolator(DecelerateInterpolator(2f)).start()
        }
        footer.alpha = 0f
        footer.animate().alpha(1f).setStartDelay(1000).setDuration(800).start()

        CountdownWidget.refreshAll(this)
    }

    override fun onResume() {
        super.onResume()
        cards.forEach { it.first = true }
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }
}
