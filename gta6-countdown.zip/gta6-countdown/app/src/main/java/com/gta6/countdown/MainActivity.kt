package com.gta6.countdown

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private class Card(
        val target: Long,
        val doneText: String,
        val numbers: List<TextView>,
        val status: TextView
    ) {
        var doneShown = false
        var first = true
    }

    private val handler = Handler(Looper.getMainLooper())
    private val cards = mutableListOf<Card>()
    private val cardViews = mutableListOf<View>()
    private val ease = PathInterpolator(0.16f, 1f, 0.3f, 1f)

    private val tick = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            for (c in cards) {
                val rem = c.target - now
                if (rem <= 0) {
                    for (n in c.numbers) setNum(n, "00", !c.first)
                    if (!c.doneShown) {
                        c.doneShown = true
                        c.status.text = c.doneText
                        ObjectAnimator.ofFloat(c.status, "alpha", 1f, 0.35f).apply {
                            duration = 1400
                            repeatCount = ValueAnimator.INFINITE
                            repeatMode = ValueAnimator.REVERSE
                            start()
                        }
                    }
                } else {
                    val s = rem / 1000
                    setNum(c.numbers[0], Fmt.two(s / 86400), !c.first)
                    setNum(c.numbers[1], Fmt.two((s % 86400) / 3600), !c.first)
                    setNum(c.numbers[2], Fmt.two((s % 3600) / 60), !c.first)
                    setNum(c.numbers[3], Fmt.two(s % 60), !c.first)
                }
                c.first = false
            }
            handler.postDelayed(this, 1000 - (System.currentTimeMillis() % 1000) + 5)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** Cambio de cifra suave: la antigua sube y se desvanece, la nueva entra desde abajo. */
    private fun setNum(tv: TextView, t: String, animate: Boolean) {
        if (tv.text.toString() == t) return
        if (!animate) {
            tv.text = t
            return
        }
        tv.animate().cancel()
        tv.animate().alpha(0f).translationY(-dp(6).toFloat()).setDuration(160)
            .withEndAction {
                tv.text = t
                tv.translationY = dp(6).toFloat()
                tv.animate().alpha(1f).translationY(0f).setDuration(380).setInterpolator(ease).start()
            }.start()
    }

    private fun label(
        t: String, size: Float, color: String, spacing: Float,
        bold: Boolean = false, gravity: Int = Gravity.CENTER
    ) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(Color.parseColor(color))
        letterSpacing = spacing
        this.gravity = gravity
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun accentLine(): View = View(this).apply {
        background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(
                Color.parseColor("#3D5AFE"), Color.parseColor("#B52DD6"),
                Color.parseColor("#FF3C78"), Color.parseColor("#FF7A2F")
            )
        )
    }

    private fun buildCard(
        title: String, date: String, target: Long, doneText: String
    ): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#D00B0714"))
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), Color.parseColor("#26FFFFFF"))
            }
            clipToOutline = true
            isClickable = true
        }
        card.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.98f).scaleY(0.98f).setDuration(250).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(350).start()
            }
            false
        }

        card.addView(accentLine(), LinearLayout.LayoutParams(-1, dp(3)))

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(18))
        }
        card.addView(body, LinearLayout.LayoutParams(-1, -2))

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        head.addView(
            label(title, 13f, "#FFFFFF", 0.18f, true, Gravity.START),
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        head.addView(label(date, 12f, "#C9B8E8", 0.05f, false, Gravity.END))
        body.addView(head)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, dp(4))
        }
        val numbers = mutableListOf<TextView>()
        val labels = listOf("DÍAS", "HORAS", "MIN", "SEG")
        labels.forEachIndexed { i, name ->
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
            }
            val n = TextView(this).apply {
                text = "00"
                textSize = 38f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                fontFeatureSettings = "tnum"
            }
            numbers.add(n)
            col.addView(n)
            col.addView(label(name, 10f, "#9F90C0", 0.2f))
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            if (i < labels.size - 1) {
                val div = View(this).apply { setBackgroundColor(Color.parseColor("#26FFFFFF")) }
                row.addView(div, LinearLayout.LayoutParams(dp(1), dp(36)))
            }
        }
        body.addView(row)

        val status = label("", 13f, "#FF6FA0", 0.2f, true)
        body.addView(status)

        cards.add(Card(target, doneText, numbers, status))
        cardViews.add(card)
        return card
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(28))
        }

        val logo = LogoView(this)
        content.addView(logo, LinearLayout.LayoutParams(-1, -2))
        val sub = label("CUENTA ATRÁS · HORA DE ESPAÑA", 11f, "#C9B8E8", 0.25f)
        content.addView(sub, LinearLayout.LayoutParams(-1, -2))

        val lp = { LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) } }
        content.addView(buildCard("SALIDA DEL JUEGO", "19 NOV 2026 · 00:00", Targets.LAUNCH, "YA DISPONIBLE"), lp())
        content.addView(buildCard("PREDESCARGA", "10 NOV 2026 · 00:00", Targets.PREDOWNLOAD, "PREDESCARGA ABIERTA"), lp())

        val footer = label(
            "Proyecto de fans · no oficial · no afiliado a Rockstar Games ni Take-Two", 10f,
            "#80FFFFFF", 0.05f
        )
        content.addView(footer, lp())

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            addView(content)
        }
        val root = FrameLayout(this)
        root.addView(ViceCityView(this), FrameLayout.LayoutParams(-1, -1))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        // Edge-to-edge (Android 15/16)
        root.setOnApplyWindowInsetsListener { _, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val b = insets.getInsets(WindowInsets.Type.systemBars())
                scroll.setPadding(b.left, b.top, b.right, b.bottom)
            } else {
                @Suppress("DEPRECATION")
                scroll.setPadding(
                    insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                )
            }
            insets
        }

        // Parallax: el logo sube más despacio que el resto y se desvanece al bajar
        scroll.setOnScrollChangeListener { _, _, y, _, _ ->
            logo.translationY = y * 0.35f
            val h = (logo.height * 1.1f).coerceAtLeast(1f)
            logo.alpha = (1f - y / h).coerceIn(0f, 1f)
        }

        // Entrada lenta y elegante
        logo.alpha = 0f
        logo.scaleX = 0.92f
        logo.scaleY = 0.92f
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(1800).setInterpolator(ease).start()

        sub.alpha = 0f
        sub.animate().alpha(1f).setStartDelay(700).setDuration(1400).start()

        cardViews.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = dp(50).toFloat()
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(900L + i * 300L).setDuration(1300).setInterpolator(ease).start()
        }
        footer.alpha = 0f
        footer.animate().alpha(1f).setStartDelay(1800).setDuration(1400).start()

        CountdownWidget.refreshAll(this)
    }

    override fun onResume() {
        super.onResume()
        cards.forEach { it.first = true }
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }
}
