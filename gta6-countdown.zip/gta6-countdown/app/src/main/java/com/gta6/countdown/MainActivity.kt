package com.gta6.countdown

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.LayoutTransition
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.min

class MainActivity : Activity(), SensorEventListener {

    private class Card(
        val target: Long,
        val doneText: String,
        val numbers: List<TextView>,
        val status: TextView,
        val bar: View,
        val extra: TextView
    ) {
        var doneShown = false
        var first = true
        var expanded = false
    }

    companion object {
        private var introPlayed = false
        private var celebrated = false
        private const val HINT = "TOCA PARA VER EL TOTAL"
    }

    private val handler = Handler(Looper.getMainLooper())
    private val cards = mutableListOf<Card>()
    private val cardViews = mutableListOf<View>()
    private val loops = mutableListOf<ValueAnimator>()
    private val ease = PathInterpolator(0.16f, 1f, 0.3f, 1f)
    private val linear = LinearInterpolator()
    private val nf: NumberFormat = NumberFormat.getIntegerInstance(Locale("es", "ES"))
    private val sb = StringBuilder()
    private var intro = 1f
    private var tilt = 0f

    private lateinit var scene: ViceCityView
    private lateinit var logo: LogoView
    private lateinit var celebration: CelebrationView

    private val tick = object : Runnable {
        override fun run() {
            renderAll(System.currentTimeMillis())
            handler.postDelayed(this, 1000 - (System.currentTimeMillis() % 1000) + 5)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- Render ----------

    private fun renderAll(now: Long) {
        val f = intro
        for (c in cards) {
            val rem = c.target - now
            if (rem <= 0) {
                for (n in c.numbers) setNum(n, "00", false)
                c.bar.scaleX = 0f
                if (!c.doneShown) {
                    c.doneShown = true
                    c.status.text = c.doneText
                    c.status.visibility = View.VISIBLE
                    val pulse = ObjectAnimator.ofFloat(c.status, "alpha", 1f, 0.35f)
                    pulse.duration = 1400
                    pulse.repeatCount = ValueAnimator.INFINITE
                    pulse.repeatMode = ValueAnimator.REVERSE
                    pulse.start()
                    loops.add(pulse)
                    if (!celebrated) {
                        celebrated = true
                        celebration.postDelayed({ celebration.play() }, 2200)
                    }
                }
            } else {
                val s = rem / 1000
                val days = s / 86400
                val hours = (s % 86400) / 3600
                val mins = (s % 3600) / 60
                val secs = s % 60
                if (f >= 1f) {
                    val a = !c.first
                    setNum(c.numbers[0], Fmt.two(days), a)
                    setNum(c.numbers[1], Fmt.two(hours), a)
                    setNum(c.numbers[2], Fmt.two(mins), a)
                    setNum(c.numbers[3], Fmt.two(secs), a)
                    // Barra del minuto: avanza de forma continua
                    val frac = 1f - (rem % 60000L) / 60000f
                    c.bar.animate().cancel()
                    c.bar.scaleX = frac
                    c.bar.animate().scaleX(min(1f, frac + 1f / 60f)).setDuration(1000)
                        .setInterpolator(linear).start()
                } else {
                    // Cuenta ascendente de entrada
                    setNum(c.numbers[0], Fmt.two((days * f).toLong()), false)
                    setNum(c.numbers[1], Fmt.two((hours * f).toLong()), false)
                    setNum(c.numbers[2], Fmt.two((mins * f).toLong()), false)
                    setNum(c.numbers[3], Fmt.two((secs * f).toLong()), false)
                }
                if (c.expanded) updateExtra(c, s)
            }
            c.first = false
        }
    }

    /** Cambio de cifra suave: la antigua sube y se desvanece, la nueva entra desde abajo. */
    private fun setNum(tv: TextView, t: String, animate: Boolean) {
        if (tv.text.toString() == t) return
        if (!animate) {
            tv.text = t
            return
        }
        tv.animate().cancel()
        tv.animate().alpha(0f).translationY(-dp(6).toFloat()).setDuration(160)
            .withEndAction {
                tv.text = t
                tv.translationY = dp(6).toFloat()
                tv.animate().alpha(1f).translationY(0f).setDuration(380).setInterpolator(ease).start()
            }.start()
    }

    private fun updateExtra(c: Card, s: Long) {
        sb.setLength(0)
        sb.append("= ").append(nf.format(s / 3600)).append(" horas\n= ")
            .append(nf.format(s / 60)).append(" minutos\n= ")
            .append(nf.format(s)).append(" segundos")
        c.extra.text = sb.toString()
    }

    // ---------- Construcción de la interfaz ----------

    private fun label(
        t: String, size: Float, color: String, spacing: Float,
        bold: Boolean = false, gravity: Int = Gravity.CENTER
    ) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(Color.parseColor(color))
        letterSpacing = spacing
        this.gravity = gravity
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun accentLine(): View = View(this).apply {
        background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(
                Color.parseColor("#3D5AFE"), Color.parseColor("#B52DD6"),
                Color.parseColor("#FF3C78"), Color.parseColor("#FF7A2F")
            )
        )
    }

    private fun addPress(v: View, s: Float) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(s).scaleY(s).setDuration(250).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(350).start()
            }
            false
        }
    }

    private fun buildCard(title: String, date: String, target: Long, doneText: String, index: Int): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#D00B0714"))
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), Color.parseColor("#26FFFFFF"))
            }
            clipToOutline = true
            isClickable = true
        }
        addPress(card, 0.98f)

        // Línea de acento con un destello que la recorre
        val accent = FrameLayout(this)
        accent.addView(accentLine(), FrameLayout.LayoutParams(-1, -1))
        val glint = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor("#00FFFFFF"), Color.parseColor("#CCFFFFFF"), Color.parseColor("#00FFFFFF"))
            )
            translationX = -dp(90).toFloat()
        }
        accent.addView(glint, FrameLayout.LayoutParams(dp(90), -1))
        card.addView(accent, LinearLayout.LayoutParams(-1, dp(3)))

        val glintAnim = ObjectAnimator.ofFloat(
            glint, View.TRANSLATION_X, -dp(90).toFloat(), resources.displayMetrics.widthPixels.toFloat()
        )
        glintAnim.duration = 7000
        glintAnim.repeatCount = ValueAnimator.INFINITE
        glintAnim.startDelay = 2600L + index * 1500L
        glintAnim.interpolator = TimeInterpolator { x -> if (x < 0.35f) x / 0.35f else 1f }
        glintAnim.start()
        loops.add(glintAnim)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            layoutTransition = LayoutTransition().apply {
                enableTransitionType(LayoutTransition.CHANGING)
                setDuration(350L)
            }
        }
        card.addView(body, LinearLayout.LayoutParams(-1, -2))

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        head.addView(
            label(title, 13f, "#FFFFFF", 0.18f, true, Gravity.START),
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        head.addView(label(date, 12f, "#C9B8E8", 0.05f, false, Gravity.END))
        body.addView(head)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, dp(4))
        }
        val numbers = mutableListOf<TextView>()
        val names = listOf("DÍAS", "HORAS", "MIN", "SEG")
        names.forEachIndexed { i, name ->
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
            }
            val n = TextView(this).apply {
                text = "00"
                textSize = 38f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                fontFeatureSettings = "tnum"
            }
            numbers.add(n)
            col.addView(n)
            col.addView(label(name, 10f, "#9F90C0", 0.2f))
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            if (i < names.size - 1) {
                val div = View(this).apply { setBackgroundColor(Color.parseColor("#26FFFFFF")) }
                row.addView(div, LinearLayout.LayoutParams(dp(1), dp(36)))
            }
        }
        body.addView(row)

        // Barra del minuto actual
        val track = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#1FFFFFFF")) }
        val bar = accentLine().apply {
            pivotX = 0f
            scaleX = 0f
        }
        track.addView(bar, FrameLayout.LayoutParams(-1, -1))
        body.addView(track, LinearLayout.LayoutParams(-1, dp(2)).apply { topMargin = dp(12) })

        val status = label("", 13f, "#FF6FA0", 0.2f, true).apply { visibility = View.GONE }
        body.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        val extra = label(HINT, 9f, "#6F6290", 0.2f)
        body.addView(extra, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        val c = Card(target, doneText, numbers, status, bar, extra)
        cards.add(c)
        cardViews.add(card)

        card.setOnClickListener { v ->
            c.expanded = !c.expanded
            if (c.expanded) {
                c.extra.textSize = 12f
                c.extra.setTextColor(Color.parseColor("#D9CCF2"))
                c.extra.letterSpacing = 0.03f
                val rem = c.target - System.currentTimeMillis()
                updateExtra(c, if (rem > 0) rem / 1000 else 0L)
            } else {
                c.extra.textSize = 9f
                c.extra.setTextColor(Color.parseColor("#6F6290"))
                c.extra.letterSpacing = 0.2f
                c.extra.text = HINT
            }
            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        }
        return card
    }

    private fun shareText(): String {
        val rem = Targets.LAUNCH - System.currentTimeMillis()
        if (rem <= 0) return "¡GTA VI ya está disponible!"
        val s = rem / 1000
        return "Faltan ${s / 86400} días, ${(s % 86400) / 3600} h y ${(s % 3600) / 60} min para GTA VI " +
            "(19 nov 2026, 00:00 hora de España)"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(28))
        }

        logo = LogoView(this)
        content.addView(logo, LinearLayout.LayoutParams(-1, -2))
        val sub = label("CUENTA ATRÁS · HORA DE ESPAÑA", 11f, "#C9B8E8", 0.25f)
        content.addView(sub, LinearLayout.LayoutParams(-1, -2))

        val lp = { LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) } }
        content.addView(buildCard("SALIDA DEL JUEGO", "19 NOV 2026 · 00:00", Targets.LAUNCH, "YA DISPONIBLE", 0), lp())
        content.addView(buildCard("PREDESCARGA", "10 NOV 2026 · 00:00", Targets.PREDOWNLOAD, "PREDESCARGA ABIERTA", 1), lp())

        val share = label("COMPARTIR CUENTA ATRÁS", 11f, "#FFFFFF", 0.2f, true).apply {
            setPadding(dp(20), dp(12), dp(20), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#33000000"))
                setStroke(dp(1), Color.parseColor("#59FFFFFF"))
                cornerRadius = dp(26).toFloat()
            }
            isClickable = true
        }
        addPress(share, 0.96f)
        share.setOnClickListener {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, shareText())
            }
            startActivity(Intent.createChooser(send, "Compartir"))
        }
        content.addView(share, lp().apply { gravity = Gravity.CENTER_HORIZONTAL })

        val footer = label(
            "Proyecto de fans · no oficial · no afiliado a Rockstar Games ni Take-Two", 10f,
            "#80FFFFFF", 0.05f
        )
        content.addView(footer, lp())

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            addView(content)
        }

        scene = ViceCityView(this)
        celebration = CelebrationView(this)
        val curtain = View(this).apply { setBackgroundColor(Color.BLACK) }
        val root = FrameLayout(this)
        root.addView(scene, FrameLayout.LayoutParams(-1, -1))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        root.addView(celebration, FrameLayout.LayoutParams(-1, -1))
        root.addView(curtain, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        // Edge-to-edge (Android 15/16)
        root.setOnApplyWindowInsetsListener { _, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val b = insets.getInsets(WindowInsets.Type.systemBars())
                scroll.setPadding(b.left, b.top, b.right, b.bottom)
            } else {
                @Suppress("DEPRECATION")
                scroll.setPadding(
                    insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                )
            }
            insets
        }

        // Parallax al hacer scroll
        scroll.setOnScrollChangeListener { _, _, y, _, _ ->
            logo.translationY = y * 0.35f
            val h = (logo.height * 1.1f).coerceAtLeast(1f)
            logo.alpha = (1f - y / h).coerceIn(0f, 1f)
        }

        // ---- Entrada cinematográfica ----
        curtain.animate().alpha(0f).setDuration(2200).withEndAction { curtain.visibility = View.GONE }.start()

        scene.scaleX = 1.14f
        scene.scaleY = 1.14f
        scene.animate().scaleX(1.06f).scaleY(1.06f).setDuration(3800).setInterpolator(ease).start()

        logo.alpha = 0f
        logo.scaleX = 0.92f
        logo.scaleY = 0.92f
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(1800).setInterpolator(ease).start()

        val breathing = ObjectAnimator.ofPropertyValuesHolder(
            logo,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.02f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.02f)
        )
        breathing.duration = 3800
        breathing.startDelay = 2200
        breathing.repeatCount = ValueAnimator.INFINITE
        breathing.repeatMode = ValueAnimator.REVERSE
        breathing.interpolator = AccelerateDecelerateInterpolator()
        breathing.start()
        loops.add(breathing)

        sub.alpha = 0f
        sub.animate().alpha(1f).setStartDelay(700).setDuration(1400).start()

        cardViews.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = dp(50).toFloat()
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(900L + i * 300L).setDuration(1300).setInterpolator(ease).start()
        }
        share.alpha = 0f
        share.animate().alpha(1f).setStartDelay(1700).setDuration(1200).start()
        footer.alpha = 0f
        footer.animate().alpha(1f).setStartDelay(2000).setDuration(1400).start()

        // Cuenta ascendente de las cifras (solo la primera vez por sesión)
        if (!introPlayed) {
            introPlayed = true
            intro = 0f
            val a = ValueAnimator.ofFloat(0f, 1f)
            a.startDelay = 1500
            a.duration = 2200
            a.interpolator = ease
            a.addUpdateListener {
                intro = it.animatedValue as Float
                renderAll(System.currentTimeMillis())
            }
            a.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    intro = 1f
                    cards.forEach { it.first = true }
                    renderAll(System.currentTimeMillis())
                }
            })
            a.start()
        }

        CountdownWidget.refreshAll(this)
    }

    // ---------- Ciclo de vida ----------

    override fun onResume() {
        super.onResume()
        cards.forEach { it.first = true }
        handler.post(tick)
        loops.forEach { it.resume() }
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (acc != null) sm.registerListener(this, acc, SensorManager.SENSOR_DELAY_GAME)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
        loops.forEach { it.pause() }
        (getSystemService(Context.SENSOR_SERVICE) as SensorManager).unregisterListener(this)
    }

    // ---------- Parallax por inclinación ----------

    override fun onSensorChanged(event: SensorEvent) {
        val x = (-event.values[0] / 9.81f).coerceIn(-1f, 1f)
        tilt += (x - tilt) * 0.08f
        scene.translationX = tilt * dp(7)
        logo.translationX = -tilt * dp(4)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
