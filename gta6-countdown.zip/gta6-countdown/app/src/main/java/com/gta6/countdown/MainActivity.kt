package com.gta6.countdown

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private class Card(val target: Long, val numbers: List<TextView>, val status: TextView)

    private val handler = Handler(Looper.getMainLooper())
    private val cards = mutableListOf<Card>()

    private val tick = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            for (c in cards) {
                val rem = c.target - now
                if (rem <= 0) {
                    c.numbers.forEach { it.text = "00" }
                    c.status.text = "¡YA DISPONIBLE!"
                } else {
                    val s = rem / 1000
                    val vals = listOf(s / 86400, (s % 86400) / 3600, (s % 3600) / 60, s % 60)
                    vals.forEachIndexed { i, v -> c.numbers[i].text = "%02d".format(v) }
                    c.status.text = ""
                }
            }
            handler.postDelayed(this, 1000 - (System.currentTimeMillis() % 1000))
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false, center: Boolean = true) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            if (center) gravity = Gravity.CENTER
        }

    private fun buildCard(title: String, subtitle: String, target: Long): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable().apply {
                setColor(Color.argb(70, 20, 5, 40))
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), Color.argb(90, 255, 255, 255))
            }
        }
        box.addView(text(title, 18f, Color.WHITE, true))
        box.addView(text(subtitle, 12f, Color.parseColor("#FFD7A8")))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(6))
        }
        val numbers = mutableListOf<TextView>()
        listOf("DÍAS", "HORAS", "MIN", "SEG").forEach { label ->
            val unit = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(10), dp(4), dp(8))
                background = GradientDrawable().apply {
                    setColor(Color.argb(110, 0, 0, 0))
                    cornerRadius = dp(14).toFloat()
                }
            }
            val n = text("00", 32f, Color.WHITE, true)
            numbers.add(n)
            unit.addView(n)
            unit.addView(text(label, 10f, Color.parseColor("#FFB4D8")))
            row.addView(unit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(4), 0, dp(4), 0)
            })
        }
        box.addView(row)
        val status = text("", 14f, Color.WHITE, true)
        box.addView(status)
        cards.add(Card(target, numbers, status))
        return box
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }

        content.addView(text("GRAND THEFT AUTO", 14f, Color.parseColor("#FFD7A8"), true))
        content.addView(text("VI", 72f, Color.WHITE, true))
        content.addView(text("Cuenta atrás · hora de España", 13f, Color.parseColor("#FFD7A8")))

        val lp = { LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) } }
        content.addView(buildCard("SALIDA DEL JUEGO", "19 nov 2026 · 00:00 (España)", Targets.LAUNCH), lp())
        content.addView(buildCard("PREDESCARGA", "10 nov 2026 · 12:00 (España)", Targets.PREDOWNLOAD), lp())
        content.addView(
            text("App no oficial hecha por fans. No afiliada a Rockstar Games ni Take-Two.", 11f,
                Color.argb(170, 255, 255, 255)),
            lp()
        )

        val scroll = ScrollView(this).apply {
            setBackgroundResource(R.drawable.bg_gradient)
            isFillViewport = true
            addView(content)
        }
        setContentView(scroll)

        // Edge-to-edge (Android 15/16): respeta barras del sistema
        scroll.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val b = insets.getInsets(WindowInsets.Type.systemBars())
                v.setPadding(b.left, b.top, b.right, b.bottom)
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
            }
            insets
        }

        // Refresca el widget si ya está puesto
        val mgr = AppWidgetManager.getInstance(this)
        mgr.getAppWidgetIds(ComponentName(this, CountdownWidget::class.java))
            .forEach { CountdownWidget.render(this, mgr, it) }
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }
}
