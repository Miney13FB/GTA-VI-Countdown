package com.gta6.countdown

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.widget.RemoteViews

class CountdownWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { render(context, manager, it) }
        scheduleNextRefresh(context)
    }

    companion object {
        private fun fill(rv: RemoteViews, chronoId: Int, doneId: Int, target: Long) {
            val remaining = target - System.currentTimeMillis()
            if (remaining > 0) {
                rv.setChronometerCountDown(chronoId, true)
                rv.setChronometer(chronoId, SystemClock.elapsedRealtime() + remaining, null, true)
                rv.setViewVisibility(chronoId, android.view.View.VISIBLE)
                rv.setViewVisibility(doneId, android.view.View.GONE)
            } else {
                rv.setViewVisibility(chronoId, android.view.View.GONE)
                rv.setViewVisibility(doneId, android.view.View.VISIBLE)
            }
        }

        fun render(context: Context, manager: AppWidgetManager, id: Int) {
            val rv = RemoteViews(context.packageName, R.layout.widget)
            fill(rv, R.id.chrono_launch, R.id.done_launch, Targets.LAUNCH)
            fill(rv, R.id.chrono_pre, R.id.done_pre, Targets.PREDOWNLOAD)
            val open = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.root, open)
            manager.updateAppWidget(id, rv)
        }

        /** Programa un refresco justo cuando termine cada cuenta atrás. */
        fun scheduleNextRefresh(context: Context) {
            val now = System.currentTimeMillis()
            val next = listOf(Targets.PREDOWNLOAD, Targets.LAUNCH).filter { it > now }.minOrNull() ?: return
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, CountdownWidget::class.java))
            val intent = Intent(context, CountdownWidget::class.java).apply {
                action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            }
            val pi = PendingIntent.getBroadcast(
                context, 1, intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarm.set(AlarmManager.RTC, next + 1000, pi)
        }
    }
}
