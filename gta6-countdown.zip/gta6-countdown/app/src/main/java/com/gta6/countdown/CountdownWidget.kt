package com.gta6.countdown

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews

/**
 * Widget grande (salida + predescarga) con DÍAS · HORAS · MIN:SEG.
 * Minutos y segundos corren solos con un Chronometer (cero consumo entre actualizaciones).
 * Días y horas se actualizan con UNA alarma exacta cada vez que cambia la hora.
 * Todas las instancias (grande y pequeño) se actualizan con una sola llamada.
 */
class CountdownWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        refreshAll(context)
    }

    override fun onEnabled(context: Context) {
        scheduleNextRefresh(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_REFRESH,
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> refreshAll(context)
        }
    }

    companion object {
        const val ACTION_REFRESH = "com.gta6.countdown.REFRESH"

        private fun fill(
            rv: RemoteViews, daysId: Int, hoursId: Int, chronoId: Int, rowId: Int, doneId: Int,
            target: Long, now: Long, elapsed: Long
        ) {
            val rem = target - now
            if (rem > 0) {
                val days = rem / 86_400_000L
                val hours = (rem % 86_400_000L) / 3_600_000L
                val sub = rem % 3_600_000L // minutos y segundos restantes de la hora actual
                rv.setTextViewText(daysId, Fmt.two(days))
                rv.setTextViewText(hoursId, Fmt.two(hours))
                rv.setChronometerCountDown(chronoId, true)
                rv.setChronometer(chronoId, elapsed + sub, null, true)
                rv.setViewVisibility(rowId, View.VISIBLE)
                rv.setViewVisibility(doneId, View.GONE)
            } else {
                rv.setViewVisibility(rowId, View.GONE)
                rv.setViewVisibility(doneId, View.VISIBLE)
            }
        }

        private fun openApp(context: Context): PendingIntent = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        private fun buildLarge(context: Context, now: Long, elapsed: Long): RemoteViews {
            val rv = RemoteViews(context.packageName, R.layout.widget)
            fill(rv, R.id.days_l, R.id.hours_l, R.id.chrono_l, R.id.row_l, R.id.done_l, Targets.LAUNCH, now, elapsed)
            fill(rv, R.id.days_p, R.id.hours_p, R.id.chrono_p, R.id.row_p, R.id.done_p, Targets.PREDOWNLOAD, now, elapsed)
            rv.setOnClickPendingIntent(R.id.root, openApp(context))
            return rv
        }

        private fun buildSmall(context: Context, now: Long, elapsed: Long): RemoteViews {
            val rv = RemoteViews(context.packageName, R.layout.widget_small)
            fill(rv, R.id.days_s, R.id.hours_s, R.id.chrono_s, R.id.row_s, R.id.done_s, Targets.LAUNCH, now, elapsed)
            rv.setOnClickPendingIntent(R.id.root_s, openApp(context))
            return rv
        }

        fun refreshAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val big = ComponentName(context, CountdownWidget::class.java)
            val small = ComponentName(context, CountdownWidgetSmall::class.java)
            val now = System.currentTimeMillis()
            val elapsed = SystemClock.elapsedRealtime()
            if (mgr.getAppWidgetIds(big).isNotEmpty()) mgr.updateAppWidget(big, buildLarge(context, now, elapsed))
            if (mgr.getAppWidgetIds(small).isNotEmpty()) mgr.updateAppWidget(small, buildSmall(context, now, elapsed))
            scheduleNextRefresh(context)
        }

        /** Una alarma justo cuando cambia la hora (o cuando termina una cuenta atrás). */
        fun scheduleNextRefresh(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val hasWidgets =
                mgr.getAppWidgetIds(ComponentName(context, CountdownWidget::class.java)).isNotEmpty() ||
                    mgr.getAppWidgetIds(ComponentName(context, CountdownWidgetSmall::class.java)).isNotEmpty()
            if (!hasWidgets) return

            val now = System.currentTimeMillis()
            val next = listOf(Targets.PREDOWNLOAD, Targets.LAUNCH)
                .map { it - now }
                .filter { it > 0 }
                .map { now + (it % 3_600_000L) + 400L }
                .minOrNull() ?: return

            val intent = Intent(context, CountdownWidget::class.java).apply { action = ACTION_REFRESH }
            val pi = PendingIntent.getBroadcast(
                context, 1, intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            try {
                if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) {
                    alarm.set(AlarmManager.RTC_WAKEUP, next, pi)
                } else {
                    alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
                }
            } catch (e: SecurityException) {
                alarm.set(AlarmManager.RTC_WAKEUP, next, pi)
            }
        }
    }
}
