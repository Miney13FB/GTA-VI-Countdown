package com.gta6.countdown

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews

/**
 * Widget con el mismo formato que la app: DÍAS · HORAS · MIN:SEG.
 * Los minutos y segundos corren solos con un Chronometer (cuenta atrás en vivo).
 * Días y horas se actualizan en cada cambio de hora con una alarma exacta.
 */
class CountdownWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { render(context, manager, it) }
        scheduleNextRefresh(context)
    }

    override fun onEnabled(context: Context) {
        scheduleNextRefresh(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> refreshAll(context)
        }
    }

    companion object {
        private fun fill(
            rv: RemoteViews, daysId: Int, hoursId: Int, chronoId: Int, rowId: Int, doneId: Int,
            target: Long, now: Long, elapsed: Long
        ) {
            val rem = target - now
            if (rem > 0) {
                val days = rem / 86_400_000L
                val hours = (rem % 86_400_000L) / 3_600_000L
                val sub = rem % 3_600_000L // minutos y segundos restantes de la hora actual
                rv.setTextViewText(daysId, "%02d".format(days))
                rv.setTextViewText(hoursId, "%02d".format(hours))
                rv.setChronometerCountDown(chronoId, true)
                rv.setChronometer(chronoId, elapsed + sub, null, true)
                rv.setViewVisibility(rowId, View.VISIBLE)
                rv.setViewVisibility(doneId, View.GONE)
            } else {
                rv.setViewVisibility(rowId, View.GONE)
                rv.setViewVisibility(doneId, View.VISIBLE)
            }
        }

        fun render(context: Context, manager: AppWidgetManager, id: Int) {
            val rv = RemoteViews(context.packageName, R.layout.widget)
            val now = System.currentTimeMillis()
            val elapsed = SystemClock.elapsedRealtime()
            fill(rv, R.id.days_l, R.id.hours_l, R.id.chrono_l, R.id.row_l, R.id.done_l, Targets.LAUNCH, now, elapsed)
            fill(rv, R.id.days_p, R.id.hours_p, R.id.chrono_p, R.id.row_p, R.id.done_p, Targets.PREDOWNLOAD, now, elapsed)
            val open = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.root, open)
            manager.updateAppWidget(id, rv)
        }

        fun refreshAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, CountdownWidget::class.java))
            ids.forEach { render(context, mgr, it) }
            scheduleNextRefresh(context)
        }

        /** Alarma justo cuando cambia la hora (o cuando termina una cuenta atrás). */
        fun scheduleNextRefresh(context: Context) {
            val now = System.currentTimeMillis()
            val next = listOf(Targets.PREDOWNLOAD, Targets.LAUNCH)
                .map { it - now }
                .filter { it > 0 }
                .map { now + (it % 3_600_000L) + 400L }
                .minOrNull() ?: return

            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, CountdownWidget::class.java))
            if (ids.isEmpty()) return
            val intent = Intent(context, CountdownWidget::class.java).apply {
                action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            }
            val pi = PendingIntent.getBroadcast(
                context, 1, intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            try {
                if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) {
                    alarm.set(AlarmManager.RTC_WAKEUP, next, pi)
                } else {
                    alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
                }
            } catch (e: SecurityException) {
                alarm.set(AlarmManager.RTC_WAKEUP, next, pi)
            }
        }
    }
}
