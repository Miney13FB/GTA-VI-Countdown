package com.gta6.countdown

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import android.view.animation.PathInterpolator

/**
 * Logotipo estilo oficial: "VI" gigante con degradado cobalto → magenta → rosa → naranja
 * y "grand theft auto" en minúsculas (blanco con contorno oscuro) por delante.
 * Un destello cruza el "VI" cada pocos segundos. En reposo no consume nada (solo se redibuja durante el destello).
 */
class LogoView(context: Context) : View(context) {

    private val vi = Path()
    private val viPath = Path()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shine = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textStroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val m = Matrix()
    private val lines = arrayOf("grand", "theft", "auto")
    private var shineShader: LinearGradient? = null

    private var viLeft = 0f
    private var viTop = 0f
    private var viW = 0f
    private var viH = 0f
    private var textSizePx = 0f
    private var bandW = 0f
    private var sweep = -1f

    private val sweepAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        interpolator = PathInterpolator(0.4f, 0f, 0.2f, 1f)
        addUpdateListener {
            sweep = it.animatedValue as Float
            invalidate()
        }
        addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                sweep = -1f
                invalidate()
                if (isAttachedToWindow && windowVisibility == VISIBLE) postDelayed(starter, 6500)
            }
        })
    }

    private val starter = Runnable {
        if (isAttachedToWindow && windowVisibility == VISIBLE && !sweepAnim.isRunning) sweepAnim.start()
    }

    init {
        // "V" y "I" en una caja de 152 x 100
        vi.moveTo(0f, 0f); vi.lineTo(34f, 0f); vi.lineTo(52f, 64f); vi.lineTo(70f, 0f)
        vi.lineTo(104f, 0f); vi.lineTo(69f, 100f); vi.lineTo(35f, 100f); vi.close()
        vi.addRect(118f, 0f, 152f, 100f, Path.Direction.CW)

        val face = Typeface.create("sans-serif-black", Typeface.NORMAL)
        textFill.typeface = face
        textFill.color = Color.WHITE
        textStroke.typeface = face
        textStroke.style = Paint.Style.STROKE
        textStroke.strokeJoin = Paint.Join.ROUND
        textStroke.color = Color.parseColor("#0B0A2A")
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, (w * 0.50f).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val wf = w.toFloat()
        val hf = h.toFloat()
        viW = wf * 0.62f
        val scale = viW / 152f
        viH = 100f * scale
        viLeft = wf * 0.31f
        viTop = (hf - viH) / 2f

        val mt = Matrix()
        mt.setScale(scale, scale)
        mt.postTranslate(viLeft, viTop)
        vi.transform(mt, viPath)

        fill.shader = LinearGradient(
            0f, viTop, 0f, viTop + viH,
            intArrayOf(
                Color.parseColor("#3D5AFE"), Color.parseColor("#B52DD6"),
                Color.parseColor("#FF3C78"), Color.parseColor("#FF7A2F")
            ),
            floatArrayOf(0f, 0.36f, 0.68f, 1f), Shader.TileMode.CLAMP
        )
        glow.shader = RadialGradient(
            viLeft + viW / 2f, viTop + viH / 2f, viW * 0.8f,
            Color.parseColor("#55FF3C78"), Color.parseColor("#00FF3C78"), Shader.TileMode.CLAMP
        )
        bandW = viW * 0.28f
        shineShader = LinearGradient(
            0f, 0f, bandW, 0f,
            intArrayOf(Color.parseColor("#00FFFFFF"), Color.parseColor("#99FFFFFF"), Color.parseColor("#00FFFFFF")),
            null, Shader.TileMode.CLAMP
        )
        shine.shader = shineShader

        textSizePx = wf * 0.125f
        textFill.textSize = textSizePx
        textStroke.textSize = textSizePx
        textStroke.strokeWidth = textSizePx * 0.16f
        textFill.letterSpacing = -0.02f
        textStroke.letterSpacing = -0.02f
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), glow)
        canvas.drawPath(viPath, fill)

        if (sweep >= 0f) {
            canvas.save()
            canvas.clipPath(viPath)
            m.setSkew(-0.4f, 0f, 0f, viTop + viH / 2f)
            m.postTranslate(viLeft - bandW + (viW + bandW * 2f) * sweep, 0f)
            shineShader?.setLocalMatrix(m)
            canvas.drawRect(viLeft, viTop, viLeft + viW, viTop + viH, shine)
            canvas.restore()
        }

        val lineH = textSizePx * 0.86f
        var y = (height - lineH * 3f) / 2f + lineH * 0.85f
        val x = width * 0.05f
        for (l in lines) {
            canvas.drawText(l, x, y, textStroke)
            canvas.drawText(l, x, y, textFill)
            y += lineH
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        postDelayed(starter, 2800)
    }

    override fun onDetachedFromWindow() {
        sweepAnim.cancel()
        removeCallbacks(starter)
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        removeCallbacks(starter)
        if (visibility == VISIBLE) {
            postDelayed(starter, 1500)
        } else {
            sweepAnim.cancel()
        }
    }
}
