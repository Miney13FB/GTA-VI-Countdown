package com.gta6.countdown

/** Formato "00" sin crear objetos en cada segundo. */
object Fmt {
    private val T = Array(100) { if (it < 10) "0$it" else it.toString() }
    fun two(n: Long): String = if (n in 0L..99L) T[n.toInt()] else n.toString()
}
