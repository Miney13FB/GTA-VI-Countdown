package com.gta6.countdown

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import java.util.Random
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Vice City al atardecer (hora dorada), dibujada en código:
 * cielo degradado, sol bajo, nubes lentas, dos capas de skyline con parallax,
 * reflejo en la bahía y palmeras que se mecen. Todo muy lento y suave.
 *
 * Optimización: skyline pre-renderizado en bitmaps ALPHA_8 (1 byte/píxel, teñidos al dibujar),
 * formas y shaders creados una sola vez, límite de ~30 fps y pausa cuando no es visible.
 */
class ViceCityView(context: Context) : View(context) {

    private class Cloud(val x: Float, val y: Float, val sx: Float, val sy: Float, val speed: Float, val orange: Boolean)

    private class Palm(
        val baseX: Float, val baseY: Float, val cx: Float, val cy: Float,
        val trunk: Path, val fronds: List<Path>, val phase: Float, val amp: Float
    )

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cloudP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val palmFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val palmStroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val twoPi = (2.0 * PI).toFloat()

    private var t = 0f
    private val startNs = System.nanoTime()
    private var lastNs = 0L

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            val n = System.nanoTime()
            if (n - lastNs >= 33_000_000L) {
                lastNs = n
                t = (n - startNs) / 1e9f
                invalidate()
            }
        }
    }

    private var hy = 0f
    private var sunX = 0f
    private var sunR = 0f
    private var farH = 0f
    private var nearH = 0f

    private var sky: Shader? = null
    private var water: Shader? = null
    private var sunGlow: Shader? = null
    private var haze: Shader? = null
    private var topShade: Shader? = null
    private var bottomShade: Shader? = null
    private var cloudPink: Shader? = null
    private var cloudOrange: Shader? = null

    private var farBmp: Bitmap? = null
    private var nearBmp: Bitmap? = null
    private var winBmp: Bitmap? = null
    private var beaconX = 0f
    private var beaconTop = 0f

    private var clouds: List<Cloud> = emptyList()
    private var palms: List<Palm> = emptyList()

    private fun c(s: String) = Color.parseColor(s)

    init {
        palmFill.style = Paint.Style.FILL
        palmFill.color = c("#050309")
        palmStroke.style = Paint.Style.STROKE
        palmStroke.strokeCap = Paint.Cap.ROUND
        palmStroke.color = c("#050309")
        palmStroke.strokeWidth = 7f * d
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        if (w == 0 || h == 0) return
        val wf = w.toFloat()
        val hf = h.toFloat()
        hy = hf * 0.80f
        sunX = wf * 0.64f
        sunR = wf * 0.85f
        farH = hf * 0.16f
        nearH = hf * 0.125f

        sky = LinearGradient(
            0f, 0f, 0f, hy,
            intArrayOf(
                c("#04050E"), c("#10103A"), c("#3B1B7A"), c("#A02A8F"),
                c("#FF3C78"), c("#FF7A3D"), c("#FFB45E")
            ),
            floatArrayOf(0f, 0.28f, 0.50f, 0.68f, 0.82f, 0.93f, 1f), Shader.TileMode.CLAMP
        )
        water = LinearGradient(0f, hy, 0f, hf, c("#1B0B3B"), c("#05030A"), Shader.TileMode.CLAMP)
        sunGlow = RadialGradient(
            sunX, hy, sunR,
            intArrayOf(c("#FFFFF0C8"), c("#FFFFB866"), c("#99FF6B35"), c("#44FF3C78"), c("#00FF3C78")),
            floatArrayOf(0f, 0.12f, 0.35f, 0.65f, 1f), Shader.TileMode.CLAMP
        )
        val hazeH = hf * 0.12f
        haze = LinearGradient(0f, hy - hazeH, 0f, hy, c("#00FF6B35"), c("#66FF8A3D"), Shader.TileMode.CLAMP)
        topShade = LinearGradient(0f, 0f, 0f, hf * 0.45f, c("#CC000000"), c("#00000000"), Shader.TileMode.CLAMP)
        bottomShade = LinearGradient(0f, hf * 0.8f, 0f, hf, c("#00000000"), c("#99000000"), Shader.TileMode.CLAMP)
        cloudPink = RadialGradient(0f, 0f, 1f, c("#99FF9AC8"), c("#00FF9AC8"), Shader.TileMode.CLAMP)
        cloudOrange = RadialGradient(0f, 0f, 1f, c("#B0FF8A3D"), c("#00FF8A3D"), Shader.TileMode.CLAMP)

        // Nubes
        val rc = Random(7)
        clouds = List(6) {
            val sx = wf * (0.18f + 0.18f * rc.nextFloat())
            val y = hy * (0.10f + 0.45f * rc.nextFloat())
            Cloud(
                rc.nextFloat(), y, sx, sx * (0.10f + 0.06f * rc.nextFloat()),
                1f / (160f + 100f * rc.nextFloat()), y > hy * 0.40f
            )
        }

        // Skyline (se recrean los bitmaps)
        farBmp?.recycle(); nearBmp?.recycle(); winBmp?.recycle()
        val tw = (wf * 1.6f).toInt()
        farBmp = skyline(tw, farH.toInt(), 11L, 10f, 22f, 0.25f, 0.95f, null, false)
        val win = Bitmap.createBitmap(tw, nearH.toInt(), Bitmap.Config.ALPHA_8)
        winBmp = win
        nearBmp = skyline(tw, nearH.toInt(), 23L, 14f, 30f, 0.22f, 0.90f, win, true)

        // Palmeras
        palms = listOf(
            palm(wf * 0.03f, hf + 8f * d, hf * 0.30f, wf * 0.10f, 0.0f, 1.6f, 1L),
            palm(wf * 0.15f, hf + 8f * d, hf * 0.20f, wf * 0.05f, 1.7f, 1.2f, 2L),
            palm(wf * 0.97f, hf + 8f * d, hf * 0.26f, -wf * 0.12f, 0.8f, 1.5f, 3L),
            palm(wf * 0.86f, hf + 8f * d, hf * 0.17f, -wf * 0.04f, 2.6f, 1.1f, 4L)
        )
    }

    private fun skyline(
        tw: Int, th: Int, seed: Long,
        minW: Float, maxW: Float, minH: Float, maxH: Float,
        windows: Bitmap?, beacon: Boolean
    ): Bitmap {
        val bmp = Bitmap.createBitmap(tw, th, Bitmap.Config.ALPHA_8)
        val cv = Canvas(bmp)
        val wc = if (windows != null) Canvas(windows) else null
        val pt = Paint().apply { color = Color.BLACK }
        val wp = Paint()
        val r = Random(seed)
        var x = 0f
        var bestTip = Float.MAX_VALUE
        val thf = th.toFloat()
        while (x < tw) {
            val bw = (minW + r.nextFloat() * (maxW - minW)) * d
            val k = r.nextFloat()
            val bh = (minH + (maxH - minH) * k * k) * thf
            val right = min(x + bw, tw.toFloat())
            val top = thf - bh
            cv.drawRect(x, top, right, thf, pt)

            var topEff = top
            if (r.nextFloat() < 0.5f) {
                val iw = (right - x) * 0.6f
                val ix = x + ((right - x) - iw) / 2f
                val ih = thf * 0.10f * (0.5f + r.nextFloat())
                cv.drawRect(ix, top - ih, ix + iw, top, pt)
                topEff = top - ih
            }
            var tip = topEff
            var tipX = (x + right) / 2f
            if (r.nextFloat() < 0.15f) {
                val sx = (x + right) / 2f
                tip = topEff - thf * 0.22f
                cv.drawRect(sx - d, tip, sx + d, topEff, pt)
                tipX = sx
            }
            if (tip < bestTip) { bestTip = tip; if (beacon) { beaconTop = tip; beaconX = tipX } }

            if (wc != null) {
                val cols = ((right - x) / (5f * d)).toInt()
                val rows = (bh / (7f * d)).toInt()
                for (i in 0 until cols) {
                    for (j in 0 until rows) {
                        if (r.nextFloat() < 0.10f) {
                            wp.alpha = 120 + r.nextInt(135)
                            val wx = x + (i * 5f + 1.5f) * d
                            val wy = top + (j * 7f + 2f) * d
                            wc.drawRect(wx, wy, wx + 1.6f * d, wy + 2.6f * d, wp)
                        }
                    }
                }
            }
            x = right + r.nextFloat() * 2f * d
        }
        return bmp
    }

    private fun palm(
        baseX: Float, baseY: Float, height: Float, lean: Float,
        phase: Float, amp: Float, seed: Long
    ): Palm {
        val trunk = Path()
        trunk.moveTo(baseX, baseY)
        trunk.quadTo(baseX + lean * 0.15f, baseY - height * 0.55f, baseX + lean, baseY - height)
        val cx = baseX + lean
        val cy = baseY - height
        val r = Random(seed)
        val n = 9
        val fronds = ArrayList<Path>()
        for (i in 0 until n) {
            val ang = Math.toRadians(-170.0 + i * (160.0 / (n - 1))).toFloat()
            val len = height * (0.45f + 0.18f * r.nextFloat())
            val dx = cos(ang)
            val dy = sin(ang)
            val tipX = cx + dx * len
            val tipY = cy + dy * len + len * 0.35f
            val c1x = cx + dx * len * 0.55f
            val c1y = cy + dy * len * 0.55f - len * 0.12f
            val nx = -dy
            val ny = dx
            val wd = len * 0.10f
            val f = Path()
            f.moveTo(cx, cy)
            f.quadTo(c1x + nx * wd, c1y + ny * wd, tipX, tipY)
            f.quadTo(c1x - nx * wd, c1y - ny * wd + len * 0.06f, cx, cy)
            f.close()
            fronds.add(f)
        }
        return Palm(baseX, baseY, cx, cy, trunk, fronds, phase, amp)
    }

    private fun drawTile(canvas: Canvas, bmp: Bitmap, offset: Float, top: Float, color: Int) {
        bmpPaint.color = color
        canvas.drawBitmap(bmp, -offset, top, bmpPaint)
        canvas.drawBitmap(bmp, -offset + bmp.width, top, bmpPaint)
    }

    override fun onDraw(canvas: Canvas) {
        val sk = sky ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL

        // Cielo + sol
        p.shader = sk
        p.alpha = 255
        canvas.drawRect(0f, 0f, w, hy, p)
        p.shader = sunGlow
        p.alpha = (232 + 23 * sin(twoPi * t / 9f)).toInt().coerceIn(0, 255)
        canvas.drawRect(0f, 0f, w, hy, p)
        p.alpha = 255

        // Nubes (muy lentas)
        for (cl in clouds) {
            val x = ((cl.x + t * cl.speed) % 1.5f - 0.25f) * w
            cloudP.shader = if (cl.orange) cloudOrange else cloudPink
            canvas.save()
            canvas.translate(x, cl.y)
            canvas.scale(cl.sx, cl.sy)
            canvas.drawCircle(0f, 0f, 1f, cloudP)
            canvas.restore()
        }

        // Skyline lejano
        farBmp?.let { drawTile(canvas, it, ((t / 180f) % 1f) * it.width, hy - farH, c("#8C4A1A6B")) }

        // Neblina del horizonte
        p.shader = haze
        canvas.drawRect(0f, hy - h * 0.12f, w, hy, p)
        p.shader = null

        // Skyline cercano + ventanas + baliza
        val nb = nearBmp
        if (nb != null) {
            val off = ((t / 110f) % 1f) * nb.width
            drawTile(canvas, nb, off, hy - nearH, c("#FF0B0616"))
            winBmp?.let { drawTile(canvas, it, off, hy - nearH, c("#D9FFC46B")) }

            val b = max(0f, sin(twoPi * t / 2.6f))
            if (b > 0.02f) {
                val by = hy - nearH + beaconTop
                var bx = beaconX - off
                if (bx < -20f * d) bx += nb.width
                p.color = c("#FF3B30")
                p.alpha = (80 * b).toInt()
                canvas.drawCircle(bx, by, 7f * d, p)
                p.alpha = (255 * b).toInt()
                canvas.drawCircle(bx, by, 2f * d, p)
                p.alpha = 255
            }
        }

        // Bahía + reflejo del sol
        p.shader = water
        canvas.drawRect(0f, hy, w, h, p)
        p.shader = null
        val lines = 16
        for (i in 0 until lines) {
            val f = i / lines.toFloat()
            val y = hy + (h - hy) * (f * f * 0.9f) + 2f * d
            val half = sunR * 0.22f * (1f - f * 0.5f) * (0.75f + 0.25f * sin(t * 1.1f + i * 1.7f))
            val cx = sunX + sin(t * 0.7f + i) * 6f * d
            p.color = c("#FFB066")
            p.alpha = (110 * (1f - f) * (0.6f + 0.4f * sin(t * 1.3f + i * 1.9f))).toInt().coerceIn(0, 255)
            canvas.drawRect(cx - half, y, cx + half, y + 2f * d, p)
        }
        p.alpha = 255

        // Palmeras
        for (pm in palms) {
            val sway = pm.amp * sin(twoPi * t / 7f + pm.phase)
            canvas.save()
            canvas.rotate(sway, pm.baseX, pm.baseY)
            canvas.drawPath(pm.trunk, palmStroke)
            for (i in pm.fronds.indices) {
                val fl = 2.2f * sin(twoPi * t / 5.3f + i * 0.9f + pm.phase)
                canvas.save()
                canvas.rotate(fl, pm.cx, pm.cy)
                canvas.drawPath(pm.fronds[i], palmFill)
                canvas.restore()
            }
            canvas.restore()
        }

        // Viñeta
        p.shader = topShade
        canvas.drawRect(0f, 0f, w, h * 0.45f, p)
        p.shader = bottomShade
        canvas.drawRect(0f, h * 0.8f, w, h, p)
        p.shader = null
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!anim.isStarted) anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) {
            if (!anim.isStarted) anim.start()
        } else {
            anim.cancel()
        }
    }
}
