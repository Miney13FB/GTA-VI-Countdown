package com.gta6.countdown

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.Shader
import android.os.PowerManager
import android.view.View
import android.view.animation.LinearInterpolator
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Vice City en hora dorada, dibujada en código. Muy lenta y suave.
 *
 * Capas: cielo con estrellas y estrella fugaz · sol bajo · nubes · pájaros · skyline lejano y cercano
 * (parallax, ventanas, baliza) · bahía con reflejo · puente con coches · luciérnagas · palmeras.
 *
 * Optimización:
 *  - Cielo, agua, puente y viñetas se pre-renderizan UNA vez en un bitmap a media resolución (en segundo plano).
 *  - Skyline en bitmaps ALPHA_8 (1 byte/píxel) teñidos al dibujar.
 *  - Estrellas, luciérnagas y luces de coches se dibujan con drawPoints (1 llamada por grupo) y arrays reutilizados.
 *  - Cero reservas de memoria por frame, colores precalculados, ~30 fps (20 con ahorro de batería) y pausa al ocultarse.
 */
class ViceCityView(context: Context) : View(context) {

    private class Cloud(val x: Float, val y: Float, val sx: Float, val sy: Float, val speed: Float, val orange: Boolean)

    private class Palm(
        val baseX: Float, val baseY: Float, val cx: Float, val cy: Float,
        val trunk: Path, val fronds: List<Path>, val phase: Float, val amp: Float
    )

    private class Skyline(val bmp: Bitmap, val beaconX: Float, val beaconTop: Float)

    private class Scene(
        val base: Bitmap, val far: Bitmap, val near: Bitmap, val win: Bitmap,
        val beaconX: Float, val beaconTop: Float, val palms: List<Palm>
    )

    private val d = resources.displayMetrics.density
    private val twoPi = (2.0 * PI).toFloat()

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cloudP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val basePaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val palmFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val palmStroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val emberPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val whiteCar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val redCar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val birdPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val birdPath = Path()

    private val cFar = Color.parseColor("#8C4A1A6B")
    private val cNear = Color.parseColor("#FF0B0616")
    private val cWin = Color.parseColor("#D9FFC46B")
    private val cRefl = Color.parseColor("#FFB066")
    private val cBeacon = Color.parseColor("#FF3B30")

    private val skyColors = intArrayOf(
        Color.parseColor("#04050E"), Color.parseColor("#10103A"), Color.parseColor("#3B1B7A"),
        Color.parseColor("#A02A8F"), Color.parseColor("#FF3C78"), Color.parseColor("#FF7A3D"),
        Color.parseColor("#FFB45E")
    )
    private val skyStops = floatArrayOf(0f, 0.28f, 0.50f, 0.68f, 0.82f, 0.93f, 1f)

    private var t = 0f
    private val startNs = System.nanoTime()
    private var lastNs = 0L
    private var frameNs = 33_000_000L

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            val n = System.nanoTime()
            if (n - lastNs >= frameNs) {
                lastNs = n
                t = (n - startNs) / 1e9f
                invalidate()
            }
        }
    }

    private var hy = 0f
    private var bridgeY = 0f
    private var sunX = 0f
    private var sunR = 0f
    private var farH = 0f
    private var nearH = 0f
    private var gen = 0
    private val dst = Rect()

    private var scene: Scene? = null
    private var sunGlow: Shader? = null
    private var haze: Shader? = null
    private var cloudPink: Shader? = null
    private var cloudOrange: Shader? = null
    private var clouds: List<Cloud> = emptyList()

    private val starPts = Array(3) { FloatArray(32) }
    private val emX = FloatArray(30)
    private val emY = FloatArray(30)
    private val emSp = FloatArray(30)
    private val emPh = FloatArray(30)
    private val emOut = Array(3) { FloatArray(20) }
    private val whitePts = FloatArray(24)
    private val redPts = FloatArray(24)

    init {
        palmFill.style = Paint.Style.FILL
        palmFill.color = Color.parseColor("#050309")
        palmStroke.style = Paint.Style.STROKE
        palmStroke.strokeCap = Paint.Cap.ROUND
        palmStroke.color = Color.parseColor("#050309")
        palmStroke.strokeWidth = 7f * d

        starPaint.strokeCap = Paint.Cap.ROUND
        starPaint.strokeWidth = 1.6f * d
        starPaint.color = Color.WHITE
        emberPaint.strokeCap = Paint.Cap.ROUND
        emberPaint.strokeWidth = 2.6f * d
        emberPaint.color = Color.parseColor("#FFC46B")
        whiteCar.strokeCap = Paint.Cap.ROUND
        whiteCar.strokeWidth = 2.2f * d
        whiteCar.color = Color.parseColor("#FFF1C8")
        redCar.strokeCap = Paint.Cap.ROUND
        redCar.strokeWidth = 2.2f * d
        redCar.color = Color.parseColor("#FF4060")
        birdPaint.style = Paint.Style.FILL
        birdPaint.color = Color.parseColor("#D01A0A2A")

        birdPath.moveTo(-1f, 0f)
        birdPath.quadTo(-0.5f, -0.6f, 0f, -0.05f)
        birdPath.quadTo(0.5f, -0.6f, 1f, 0f)
        birdPath.quadTo(0.5f, -0.35f, 0f, 0.12f)
        birdPath.quadTo(-0.5f, -0.35f, -1f, 0f)
        birdPath.close()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        if (w == 0 || h == 0) return
        val wf = w.toFloat()
        val hf = h.toFloat()
        hy = hf * 0.80f
        bridgeY = hy + (hf - hy) * 0.07f
        sunX = wf * 0.64f
        sunR = wf * 0.85f
        farH = hf * 0.16f
        nearH = hf * 0.125f
        dst.set(0, 0, w, h)

        sunGlow = RadialGradient(
            sunX, hy, sunR,
            intArrayOf(
                Color.parseColor("#FFFFF0C8"), Color.parseColor("#FFFFB866"), Color.parseColor("#99FF6B35"),
                Color.parseColor("#44FF3C78"), Color.parseColor("#00FF3C78")
            ),
            floatArrayOf(0f, 0.12f, 0.35f, 0.65f, 1f), Shader.TileMode.CLAMP
        )
        haze = LinearGradient(
            0f, hy - hf * 0.12f, 0f, hy,
            Color.parseColor("#00FF6B35"), Color.parseColor("#66FF8A3D"), Shader.TileMode.CLAMP
        )
        cloudPink = RadialGradient(
            0f, 0f, 1f, Color.parseColor("#99FF9AC8"), Color.parseColor("#00FF9AC8"), Shader.TileMode.CLAMP
        )
        cloudOrange = RadialGradient(
            0f, 0f, 1f, Color.parseColor("#B0FF8A3D"), Color.parseColor("#00FF8A3D"), Shader.TileMode.CLAMP
        )

        val r = Random(7)
        clouds = List(6) {
            val sx = wf * (0.18f + 0.18f * r.nextFloat())
            val y = hy * (0.10f + 0.45f * r.nextFloat())
            Cloud(r.nextFloat(), y, sx, sx * (0.10f + 0.06f * r.nextFloat()), 1f / (160f + 100f * r.nextFloat()), y > hy * 0.40f)
        }
        for (g in 0 until 3) {
            for (i in 0 until 16) {
                starPts[g][i * 2] = r.nextFloat() * wf
                starPts[g][i * 2 + 1] = r.nextFloat() * hy * 0.38f
            }
        }
        for (i in 0 until 30) {
            emX[i] = r.nextFloat() * wf
            emY[i] = r.nextFloat() * hf * 0.75f
            emSp[i] = (8f + 14f * r.nextFloat()) * d
            emPh[i] = r.nextFloat() * 6.28f
        }

        // Trabajo pesado fuera del hilo principal
        val g = ++gen
        val hyL = hy
        val bridgeL = bridgeY
        val farHL = farH.toInt()
        val nearHL = nearH.toInt()
        val th = Thread {
            val base = bakeBase(w, h, hyL, bridgeL)
            val tw = (wf * 1.6f).toInt()
            val far = skyline(tw, farHL, 11L, 10f, 22f, 0.25f, 0.95f, null, false)
            val win = Bitmap.createBitmap(tw, nearHL, Bitmap.Config.ALPHA_8)
            val near = skyline(tw, nearHL, 23L, 14f, 30f, 0.22f, 0.90f, win, true)
            val baseY = hf + 8f * d
            val palms = listOf(
                palm(wf * 0.03f, baseY, hf * 0.30f, wf * 0.10f, 0.0f, 1.6f, 1L),
                palm(wf * 0.15f, baseY, hf * 0.20f, wf * 0.05f, 1.7f, 1.2f, 2L),
                palm(wf * 0.97f, baseY, hf * 0.26f, -wf * 0.12f, 0.8f, 1.5f, 3L),
                palm(wf * 0.86f, baseY, hf * 0.17f, -wf * 0.04f, 2.6f, 1.1f, 4L)
            )
            val sc = Scene(base, far.bmp, near.bmp, win, near.beaconX, near.beaconTop, palms)
            post {
                if (g == gen) {
                    scene = sc
                    invalidate()
                }
            }
        }
        th.priority = Thread.MIN_PRIORITY
        th.start()
    }

    private fun bakeBase(w: Int, h: Int, horizon: Float, bridge: Float): Bitmap {
        val bmp = Bitmap.createBitmap(max(1, w / 2), max(1, h / 2), Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.scale(0.5f, 0.5f)
        val wf = w.toFloat()
        val hf = h.toFloat()
        val pt = Paint()

        pt.shader = LinearGradient(0f, 0f, 0f, horizon, skyColors, skyStops, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, wf, horizon + 1f, pt)
        pt.shader = LinearGradient(
            0f, horizon, 0f, hf,
            Color.parseColor("#1B0B3B"), Color.parseColor("#05030A"), Shader.TileMode.CLAMP
        )
        cv.drawRect(0f, horizon, wf, hf, pt)

        // Puente sobre la bahía
        pt.shader = null
        pt.color = Color.parseColor("#0A0614")
        cv.drawRect(0f, bridge, wf, bridge + 3.5f * d, pt)
        var px = 20f * d
        while (px < wf) {
            cv.drawRect(px, bridge, px + 5f * d, bridge + (hf - horizon) * 0.06f, pt)
            px += 78f * d
        }

        // Viñetas
        pt.shader = LinearGradient(
            0f, 0f, 0f, hf * 0.45f,
            Color.parseColor("#CC000000"), Color.parseColor("#00000000"), Shader.TileMode.CLAMP
        )
        cv.drawRect(0f, 0f, wf, hf * 0.45f, pt)
        pt.shader = LinearGradient(
            0f, hf * 0.8f, 0f, hf,
            Color.parseColor("#00000000"), Color.parseColor("#99000000"), Shader.TileMode.CLAMP
        )
        cv.drawRect(0f, hf * 0.8f, wf, hf, pt)
        return bmp
    }

    private fun skyline(
        tw: Int, th: Int, seed: Long,
        minW: Float, maxW: Float, minH: Float, maxH: Float,
        windows: Bitmap?, beacon: Boolean
    ): Skyline {
        val bmp = Bitmap.createBitmap(tw, th, Bitmap.Config.ALPHA_8)
        val cv = Canvas(bmp)
        val wc = if (windows != null) Canvas(windows) else null
        val pt = Paint()
        pt.color = Color.BLACK
        val wp = Paint()
        wp.color = Color.BLACK
        val r = Random(seed)
        var x = 0f
        var bestTip = Float.MAX_VALUE
        var bx = 0f
        var bt = 0f
        val thf = th.toFloat()
        while (x < tw) {
            val bw = (minW + r.nextFloat() * (maxW - minW)) * d
            val k = r.nextFloat()
            val bh = (minH + (maxH - minH) * k * k) * thf
            val right = min(x + bw, tw.toFloat())
            val top = thf - bh
            cv.drawRect(x, top, right, thf, pt)

            var topEff = top
            if (r.nextFloat() < 0.5f) {
                val iw = (right - x) * 0.6f
                val ix = x + ((right - x) - iw) / 2f
                val ih = thf * 0.10f * (0.5f + r.nextFloat())
                cv.drawRect(ix, top - ih, ix + iw, top, pt)
                topEff = top - ih
            }
            var tip = topEff
            var tipX = (x + right) / 2f
            if (r.nextFloat() < 0.15f) {
                val sx = (x + right) / 2f
                tip = topEff - thf * 0.22f
                cv.drawRect(sx - d, tip, sx + d, topEff, pt)
                tipX = sx
            }
            if (tip < bestTip) {
                bestTip = tip
                if (beacon) {
                    bt = tip
                    bx = tipX
                }
            }

            if (wc != null) {
                val cols = ((right - x) / (5f * d)).toInt()
                val rows = (bh / (7f * d)).toInt()
                for (i in 0 until cols) {
                    for (j in 0 until rows) {
                        if (r.nextFloat() < 0.10f) {
                            wp.alpha = 120 + r.nextInt(135)
                            val wx = x + (i * 5f + 1.5f) * d
                            val wy = top + (j * 7f + 2f) * d
                            wc.drawRect(wx, wy, wx + 1.6f * d, wy + 2.6f * d, wp)
                        }
                    }
                }
            }
            x = right + r.nextFloat() * 2f * d
        }
        return Skyline(bmp, bx, bt)
    }

    private fun palm(
        baseX: Float, baseY: Float, height: Float, lean: Float,
        phase: Float, amp: Float, seed: Long
    ): Palm {
        val trunk = Path()
        trunk.moveTo(baseX, baseY)
        trunk.quadTo(baseX + lean * 0.15f, baseY - height * 0.55f, baseX + lean, baseY - height)
        val cx = baseX + lean
        val cy = baseY - height
        val r = Random(seed)
        val n = 9
        val fronds = ArrayList<Path>()
        for (i in 0 until n) {
            val ang = Math.toRadians(-170.0 + i * (160.0 / (n - 1))).toFloat()
            val len = height * (0.45f + 0.18f * r.nextFloat())
            val dx = cos(ang)
            val dy = sin(ang)
            val tipX = cx + dx * len
            val tipY = cy + dy * len + len * 0.35f
            val c1x = cx + dx * len * 0.55f
            val c1y = cy + dy * len * 0.55f - len * 0.12f
            val nx = -dy
            val ny = dx
            val wd = len * 0.10f
            val f = Path()
            f.moveTo(cx, cy)
            f.quadTo(c1x + nx * wd, c1y + ny * wd, tipX, tipY)
            f.quadTo(c1x - nx * wd, c1y - ny * wd + len * 0.06f, cx, cy)
            f.close()
            fronds.add(f)
        }
        return Palm(baseX, baseY, cx, cy, trunk, fronds, phase, amp)
    }

    private fun drawTile(canvas: Canvas, bmp: Bitmap, offset: Float, top: Float, color: Int) {
        bmpPaint.color = color
        canvas.drawBitmap(bmp, -offset, top, bmpPaint)
        canvas.drawBitmap(bmp, -offset + bmp.width, top, bmpPaint)
    }

    override fun onDraw(canvas: Canvas) {
        val sc = scene ?: return
        val w = width.toFloat()
        val h = height.toFloat()

        // Cielo + agua + puente + viñetas (un solo bitmap)
        canvas.drawBitmap(sc.base, null, dst, basePaint)

        // Sol (late muy despacio)
        p.style = Paint.Style.FILL
        p.shader = sunGlow
        p.alpha = (232 + 23 * sin(twoPi * t / 9f)).toInt().coerceIn(0, 255)
        canvas.drawRect(0f, 0f, w, hy, p)
        p.shader = null
        p.alpha = 255

        // Estrellas
        for (g in 0 until 3) {
            starPaint.alpha = (60 + 150 * (0.5f + 0.5f * sin(t * 0.9f + g * 2.1f))).toInt()
            canvas.drawPoints(starPts[g], starPaint)
        }

        // Estrella fugaz cada 19 s
        val cyc = 19f
        val ph = t % cyc
        if (ph < 0.9f) {
            val pr = ph / 0.9f
            val idx = (t / cyc).toInt()
            val x0 = w * (0.25f + 0.6f * ((idx * 0.618f) % 1f))
            val y0 = hy * (0.04f + 0.18f * ((idx * 0.381f) % 1f))
            val dirX = -0.82f
            val dirY = 0.57f
            val dist = w * 0.35f * pr
            val headX = x0 + dirX * dist
            val headY = y0 + dirY * dist
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.6f * d
            p.strokeCap = Paint.Cap.ROUND
            p.color = Color.WHITE
            for (k in 0 until 4) {
                p.alpha = (255 * (1f - pr) * (1f - k * 0.24f)).toInt().coerceIn(0, 255)
                val s0 = k * 0.025f * w
                val s1 = (k + 1) * 0.025f * w
                canvas.drawLine(headX - dirX * s0, headY - dirY * s0, headX - dirX * s1, headY - dirY * s1, p)
            }
            p.style = Paint.Style.FILL
            p.alpha = 255
        }

        // Nubes (muy lentas)
        for (cl in clouds) {
            val x = ((cl.x + t * cl.speed) % 1.5f - 0.25f) * w
            cloudP.shader = if (cl.orange) cloudOrange else cloudPink
            canvas.save()
            canvas.translate(x, cl.y)
            canvas.scale(cl.sx, cl.sy)
            canvas.drawCircle(0f, 0f, 1f, cloudP)
            canvas.restore()
        }

        // Bandada de pájaros cruzando
        val pr2 = ((t / 50f) + 0.2f) % 1f
        val bx0 = (-0.1f + pr2 * 1.2f) * w
        val by0 = hy * 0.62f + sin(pr2 * 6f) * hy * 0.02f
        for (i in 0 until 5) {
            val ox = i * 15f * d
            val oy = (((i * 37) % 11) - 5) * d * 1.5f
            val fl = 0.35f + 0.65f * abs(sin(t * 5f + i))
            canvas.save()
            canvas.translate(bx0 + ox, by0 + oy)
            canvas.scale(7f * d, 7f * d * fl)
            canvas.drawPath(birdPath, birdPaint)
            canvas.restore()
        }

        // Skyline lejano + neblina
        drawTile(canvas, sc.far, ((t / 180f) % 1f) * sc.far.width, hy - farH, cFar)
        p.shader = haze
        canvas.drawRect(0f, hy - h * 0.12f, w, hy, p)
        p.shader = null

        // Skyline cercano + ventanas + baliza
        val off = ((t / 110f) % 1f) * sc.near.width
        drawTile(canvas, sc.near, off, hy - nearH, cNear)
        drawTile(canvas, sc.win, off, hy - nearH, cWin)
        val b = max(0f, sin(twoPi * t / 2.6f))
        if (b > 0.02f) {
            val by = hy - nearH + sc.beaconTop
            var bx = sc.beaconX - off
            if (bx < -20f * d) bx += sc.near.width
            p.color = cBeacon
            p.alpha = (80 * b).toInt()
            canvas.drawCircle(bx, by, 7f * d, p)
            p.alpha = (255 * b).toInt()
            canvas.drawCircle(bx, by, 2f * d, p)
            p.alpha = 255
        }

        // Reflejo del sol en la bahía
        val lines = 16
        p.color = cRefl
        for (i in 0 until lines) {
            val f = i / lines.toFloat()
            val y = hy + (h - hy) * (f * f * 0.9f) + 2f * d
            val half = sunR * 0.22f * (1f - f * 0.5f) * (0.75f + 0.25f * sin(t * 1.1f + i * 1.7f))
            val cx = sunX + sin(t * 0.7f + i) * 6f * d
            p.alpha = (110 * (1f - f) * (0.6f + 0.4f * sin(t * 1.3f + i * 1.9f))).toInt().coerceIn(0, 255)
            canvas.drawRect(cx - half, y, cx + half, y + 2f * d, p)
        }
        p.alpha = 255

        // Coches cruzando el puente
        for (i in 0 until 12) {
            whitePts[i * 2] = ((i / 12f + t * 0.035f) % 1f) * w
            whitePts[i * 2 + 1] = bridgeY - 1.5f * d
            var fr = (i / 12f + 0.04f - t * 0.028f) % 1f
            if (fr < 0f) fr += 1f
            redPts[i * 2] = fr * w
            redPts[i * 2 + 1] = bridgeY + 1.6f * d
        }
        canvas.drawPoints(whitePts, whiteCar)
        canvas.drawPoints(redPts, redCar)

        // Luciérnagas
        val span = h * 0.75f
        for (g in 0 until 3) {
            val out = emOut[g]
            for (i in 0 until 10) {
                val idx = g * 10 + i
                var y = (emY[idx] - t * emSp[idx]) % span
                if (y < 0f) y += span
                out[i * 2] = emX[idx] + sin(t * 0.5f + emPh[idx]) * 14f * d
                out[i * 2 + 1] = y + h * 0.22f
            }
            emberPaint.alpha = (40 + 120 * (0.5f + 0.5f * sin(t * 0.8f + g * 2f))).toInt()
            canvas.drawPoints(out, emberPaint)
        }

        // Palmeras
        for (pm in sc.palms) {
            val sway = pm.amp * sin(twoPi * t / 7f + pm.phase)
            canvas.save()
            canvas.rotate(sway, pm.baseX, pm.baseY)
            canvas.drawPath(pm.trunk, palmStroke)
            for (i in pm.fronds.indices) {
                val fl = 2.2f * sin(twoPi * t / 5.3f + i * 0.9f + pm.phase)
                canvas.save()
                canvas.rotate(fl, pm.cx, pm.cy)
                canvas.drawPath(pm.fronds[i], palmFill)
                canvas.restore()
            }
            canvas.restore()
        }
    }

    private fun updateFrameRate() {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        frameNs = if (pm.isPowerSaveMode) 66_000_000L else 33_000_000L
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        updateFrameRate()
        if (!anim.isStarted) anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) {
            updateFrameRate()
            if (!anim.isStarted) anim.start()
        } else {
            anim.cancel()
        }
    }
}
