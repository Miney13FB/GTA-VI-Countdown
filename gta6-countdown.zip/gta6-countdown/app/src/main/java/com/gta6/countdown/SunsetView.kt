package com.gta6.countdown

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

/** Fondo animado estilo synthwave: cielo, estrellas que parpadean, sol con rayas y rejilla en movimiento. */
class SunsetView(context: Context) : View(context) {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clearPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
    private val density = resources.displayMetrics.density
    private var t = 0f

    private var sky: Shader? = null
    private var floor: Shader? = null
    private var glow: Shader? = null
    private var sunShader: Shader? = null

    // x, y, fase, velocidad (entera para bucle perfecto), radio
    private val stars = Array(70) {
        floatArrayOf(
            Random.nextFloat(), Random.nextFloat() * 0.5f, Random.nextFloat() * 6.2832f,
            (1 + Random.nextInt(3)).toFloat(), 1f + Random.nextFloat() * 2f
        )
    }

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 6000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    private fun c(s: String) = Color.parseColor(s)
    private val twoPi = (2.0 * PI).toFloat()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val wf = w.toFloat()
        val hf = h.toFloat()
        val hy = hf * 0.60f
        val r0 = wf * 0.30f
        val cy = hy - r0 * 0.55f
        sky = LinearGradient(
            0f, 0f, 0f, hy,
            intArrayOf(c("#0E0322"), c("#3A0E52"), c("#B0287A"), c("#FF8A3D")),
            floatArrayOf(0f, 0.45f, 0.8f, 1f), Shader.TileMode.CLAMP
        )
        floor = LinearGradient(0f, hy, 0f, hf, c("#3A0F5C"), c("#12031F"), Shader.TileMode.CLAMP)
        glow = RadialGradient(
            wf / 2f, cy, r0 * 2.1f,
            intArrayOf(c("#99FF8A3D"), c("#00FF8A3D")), null, Shader.TileMode.CLAMP
        )
        sunShader = LinearGradient(0f, cy - r0, 0f, cy + r0, c("#FFD36B"), c("#E8368F"), Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val hy = h * 0.60f
        val cx = w / 2f
        val r0 = w * 0.30f
        val cy = hy - r0 * 0.55f

        // Cielo
        p.style = Paint.Style.FILL
        p.shader = sky
        canvas.drawRect(0f, 0f, w, hy + 1f, p)
        p.shader = null

        // Estrellas
        for (s in stars) {
            val a = 0.5f + 0.5f * sin(twoPi * t * s[3] + s[2])
            p.color = Color.WHITE
            p.alpha = (50 + 205 * a).toInt()
            canvas.drawCircle(s[0] * w, s[1] * h, s[4] * density * 0.6f, p)
        }
        p.alpha = 255

        // Resplandor del sol
        p.shader = glow
        p.alpha = (200 + 55 * sin(twoPi * t * 2f)).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx, cy, r0 * 2.1f, p)
        p.shader = null
        p.alpha = 255

        // Sol con rayas recortadas
        val r = r0 * (1f + 0.015f * sin(twoPi * t * 2f))
        val save = canvas.saveLayer(0f, 0f, w, h, null)
        p.shader = sunShader
        canvas.drawCircle(cx, cy, r, p)
        p.shader = null
        val top = cy + r * 0.05f
        val gap = r * 0.95f / 6f
        for (i in 0 until 6) {
            val y = top + i * gap + gap * 0.15f
            val th = gap * (0.10f + 0.12f * i)
            canvas.drawRect(cx - r, y, cx + r, y + th, clearPaint)
        }
        canvas.restoreToCount(save)

        // Suelo
        p.shader = floor
        canvas.drawRect(0f, hy, w, h, p)
        p.shader = null

        // Rejilla en perspectiva (se mueve hacia ti)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f * density
        val lines = 14
        for (j in 0 until lines) {
            val prog = ((j + t) % lines.toFloat()) / lines
            val y = hy + (h - hy) * prog * prog
            p.color = c("#FF4FB0")
            p.alpha = (30 + 200 * prog).toInt().coerceIn(0, 255)
            canvas.drawLine(0f, y, w, y, p)
        }
        for (i in -12..12) {
            p.color = c("#FF4FB0")
            p.alpha = 110
            canvas.drawLine(cx + i * w * 0.012f, hy, cx + i * w * 0.22f, h, p)
        }

        // Línea de horizonte brillante
        p.color = c("#FFB4D8")
        p.alpha = 230
        p.strokeWidth = 2.5f * density
        canvas.drawLine(0f, hy, w, hy, p)

        p.style = Paint.Style.FILL
        p.alpha = 255
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!anim.isStarted) anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) {
            if (!anim.isStarted) anim.start()
        } else {
            anim.cancel()
        }
    }
}
