package com.gta6.countdown

import java.util.Calendar
import java.util.TimeZone

/** Todas las fechas están en hora de España peninsular (Europe/Madrid). */
object Targets {
    private fun madrid(year: Int, month: Int, day: Int, hour: Int): Long {
        val c = Calendar.getInstance(TimeZone.getTimeZone("Europe/Madrid"))
        c.clear()
        c.set(year, month, day, hour, 0, 0)
        return c.timeInMillis
    }

    // Salida: 19 de noviembre de 2026, 00:00
    val LAUNCH: Long = madrid(2026, Calendar.NOVEMBER, 19, 0)

    // Predescarga: 10 de noviembre de 2026, 12:00
    val PREDOWNLOAD: Long = madrid(2026, Calendar.NOVEMBER, 10, 12)
}
