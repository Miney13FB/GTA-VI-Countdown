# GTA VI Countdown (no oficial) · v3

Estilo basado en la identidad oficial de GTA VI: Vice City en hora dorada,
logotipo con degradado cobalto → magenta → rosa → naranja y "grand theft auto" en minúsculas.

- Salida: 19 nov 2026 00:00 (hora España) · Predescarga: 10 nov 2026 00:00 (hora España)
- Widget grande (salida + predescarga) y widget pequeño 3x1 (salida).
- Toca una tarjeta para ver el total en horas, minutos y segundos.

Fechas en `app/src/main/java/com/gta6/countdown/Targets.kt`.
