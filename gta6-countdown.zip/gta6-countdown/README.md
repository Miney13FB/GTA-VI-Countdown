# GTA VI Countdown (no oficial)

- Salida: 19 nov 2026 00:00 (hora España)
- Predescarga: 10 nov 2026 00:00 (hora España)
- Fondo animado synthwave, animaciones de entrada y de cada cifra.
- Widget con DÍAS · HORAS · MIN:SEG (min y seg corren en vivo).

Las fechas se cambian en `app/src/main/java/com/gta6/countdown/Targets.kt`.
