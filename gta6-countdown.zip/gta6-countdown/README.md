# GTA VI Countdown (no oficial)

- Cuenta atrás a la salida: 19 nov 2026 00:00 (hora España)
- Cuenta atrás a la predescarga: 10 nov 2026 12:00 (hora España)
- Widget de pantalla de inicio con horas:min:seg en vivo.

Las fechas se cambian en `app/src/main/java/com/gta6/countdown/Targets.kt`.

## Compilar
Sube todo a GitHub (rama main). En la pestaña Actions se compila solo y el APK
aparece en Releases (y como artefacto del workflow).
