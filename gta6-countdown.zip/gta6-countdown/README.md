# GTA VI Countdown (no oficial)

Estilo basado en la identidad oficial de GTA VI: Vice City en hora dorada,
logotipo con degradado cobalto → magenta → rosa → naranja y "grand theft auto" en minúsculas.

- Salida: 19 nov 2026 00:00 (hora España)
- Predescarga: 10 nov 2026 00:00 (hora España)
- Widget con DÍAS · HORAS · MIN:SEG (min y seg corren en vivo).

Fechas en `app/src/main/java/com/gta6/countdown/Targets.kt`.
