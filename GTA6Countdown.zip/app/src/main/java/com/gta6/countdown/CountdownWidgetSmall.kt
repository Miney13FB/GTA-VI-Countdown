package com.gta6.countdown

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context

/** Widget pequeño (3x1): solo la salida del juego. Comparte toda la lógica con el grande. */
class CountdownWidgetSmall : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        CountdownWidget.refreshAll(context)
    }

    override fun onEnabled(context: Context) {
        CountdownWidget.scheduleNextRefresh(context)
    }

    override fun onDisabled(context: Context) {
        CountdownWidget.cancelRefreshIfUnused(context)
    }
}
