package com.gta6.countdown

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Pantalla principal deliberadamente sencilla: solo muestra las dos cuentas atrás. */
class MainActivity : Activity() {

    private data class CountdownCard(
        val target: Long,
        val numbers: List<TextView>,
        val finished: TextView
    )

    private val handler = Handler(Looper.getMainLooper())
    private val cards = mutableListOf<CountdownCard>()

    private val ticker = object : Runnable {
        override fun run() {
            updateCounters(System.currentTimeMillis())
            val delay = 1_000L - (System.currentTimeMillis() % 1_000L)
            handler.postDelayed(this, delay.coerceAtLeast(50L))
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun makeText(
        value: String,
        size: Float,
        color: Int,
        bold: Boolean = false,
        gravity: Int = Gravity.START
    ): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        this.gravity = gravity
        if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
    }

    private fun cardBackground(): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(Color.rgb(24, 28, 37))
        cornerRadius = dp(16).toFloat()
        setStroke(dp(1), Color.rgb(49, 55, 68))
    }

    private fun buildCountdownCard(
        title: String,
        date: String,
        target: Long,
        finishedMessage: String
    ): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBackground()
            setPadding(dp(16), dp(15), dp(16), dp(15))
        }

        val heading = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        heading.addView(
            makeText(title, 13f, Color.WHITE, bold = true),
            LinearLayout.LayoutParams(0, dp(22), 1f)
        )
        heading.addView(
            makeText(date, 11f, Color.rgb(164, 172, 187), gravity = Gravity.END),
            LinearLayout.LayoutParams(-2, dp(22))
        )
        card.addView(heading)

        val metricRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(4))
        }
        val values = mutableListOf<TextView>()
        val labels = listOf("DÍAS", "HORAS", "MIN", "SEG")

        labels.forEach { label ->
            val metric = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
            }
            val number = makeText(
                "00", 31f, Color.WHITE, gravity = Gravity.CENTER
            ).apply {
                typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                fontFeatureSettings = "tnum"
                includeFontPadding = false
            }
            values.add(number)
            metric.addView(number, LinearLayout.LayoutParams(-1, dp(40)))
            metric.addView(
                makeText(label, 9f, Color.rgb(145, 154, 171), bold = true, gravity = Gravity.CENTER),
                LinearLayout.LayoutParams(-1, dp(16))
            )
            metricRow.addView(metric, LinearLayout.LayoutParams(0, -2, 1f))
        }
        card.addView(metricRow)

        val finished = makeText(
            finishedMessage, 12f, Color.rgb(245, 132, 162), bold = true, gravity = Gravity.CENTER
        ).apply {
            visibility = View.GONE
            setPadding(0, dp(10), 0, 0)
            contentDescription = finishedMessage
        }
        card.addView(finished, LinearLayout.LayoutParams(-1, -2))
        cards.add(CountdownCard(target, values, finished))
        return card
    }

    private fun updateCounters(now: Long) {
        cards.forEach { card ->
            val remainingMillis = card.target - now
            val parts = CountdownTime.fromRemainingMillis(remainingMillis)
            val values = longArrayOf(parts.days, parts.hours, parts.minutes, parts.seconds)

            card.numbers.forEachIndexed { index, view ->
                val text = Fmt.two(values[index])
                if (view.text.toString() != text) view.text = text
            }
            card.finished.visibility = if (remainingMillis <= 0L) View.VISIBLE else View.GONE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(11, 13, 18)
        window.navigationBarColor = Color.rgb(11, 13, 18)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        content.addView(
            makeText("GTA VI", 35f, Color.WHITE, bold = true),
            LinearLayout.LayoutParams(-1, -2)
        )
        content.addView(
            makeText("CUENTA ATRÁS", 11f, Color.rgb(240, 113, 151), bold = true).apply {
                letterSpacing = 0.12f
            },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) }
        )
        content.addView(
            makeText("Hora peninsular española · Europe/Madrid", 11f, Color.rgb(145, 154, 171)),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
        )

        content.addView(
            buildCountdownCard(
                title = "PREDESCARGA",
                date = "10 NOV 2026 · 00:00",
                target = Targets.PREDOWNLOAD,
                finishedMessage = "PREDESCARGA DISPONIBLE"
            ),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) }
        )
        content.addView(
            buildCountdownCard(
                title = "LANZAMIENTO",
                date = "19 NOV 2026 · 00:00",
                target = Targets.LAUNCH,
                finishedMessage = "GTA VI YA ESTÁ DISPONIBLE"
            ),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
        )

        val scroll = ScrollView(this).apply {
            // ScrollView expone esta propiedad como isFillViewport en Kotlin.
            isFillViewport = true
            clipToPadding = false
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setBackgroundColor(Color.rgb(11, 13, 18))
            addView(content)
        }

        scroll.setOnApplyWindowInsetsListener { view, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                view.setPadding(
                    dp(20) + bars.left, dp(24) + bars.top,
                    dp(20) + bars.right, dp(24) + bars.bottom
                )
            } else {
                @Suppress("DEPRECATION")
                view.setPadding(
                    dp(20) + insets.systemWindowInsetLeft,
                    dp(24) + insets.systemWindowInsetTop,
                    dp(20) + insets.systemWindowInsetRight,
                    dp(24) + insets.systemWindowInsetBottom
                )
            }
            insets
        }

        setContentView(scroll)
        updateCounters(System.currentTimeMillis())
        CountdownWidget.refreshAll(this)
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(ticker)
        ticker.run()
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        cards.clear()
        super.onDestroy()
    }
}
