package com.gta6.countdown

/** Partes de una cuenta atrás, calculadas con redondeo hacia arriba al segundo visible. */
data class CountdownParts(
    val days: Long,
    val hours: Long,
    val minutes: Long,
    val seconds: Long
)

object CountdownTime {
    fun fromRemainingMillis(remainingMillis: Long): CountdownParts {
        val totalSeconds = if (remainingMillis > 0L) (remainingMillis + 999L) / 1_000L else 0L
        return CountdownParts(
            days = totalSeconds / 86_400L,
            hours = (totalSeconds % 86_400L) / 3_600L,
            minutes = (totalSeconds % 3_600L) / 60L,
            seconds = totalSeconds % 60L
        )
    }
}
