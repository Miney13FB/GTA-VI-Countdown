package com.gta6.countdown

import org.junit.Assert.assertEquals
import org.junit.Test
import java.util.Calendar
import java.util.TimeZone

class CountdownLogicTest {

    @Test
    fun launchTargetIsMidnightInMadrid() {
        val calendar = Calendar.getInstance(TimeZone.getTimeZone("Europe/Madrid")).apply {
            timeInMillis = Targets.LAUNCH
        }
        assertEquals(2026, calendar.get(Calendar.YEAR))
        assertEquals(Calendar.NOVEMBER, calendar.get(Calendar.MONTH))
        assertEquals(19, calendar.get(Calendar.DAY_OF_MONTH))
        assertEquals(0, calendar.get(Calendar.HOUR_OF_DAY))
        assertEquals(0, calendar.get(Calendar.MINUTE))
    }

    @Test
    fun predownloadTargetIsMidnightInMadrid() {
        val calendar = Calendar.getInstance(TimeZone.getTimeZone("Europe/Madrid")).apply {
            timeInMillis = Targets.PREDOWNLOAD
        }
        assertEquals(2026, calendar.get(Calendar.YEAR))
        assertEquals(Calendar.NOVEMBER, calendar.get(Calendar.MONTH))
        assertEquals(10, calendar.get(Calendar.DAY_OF_MONTH))
        assertEquals(0, calendar.get(Calendar.HOUR_OF_DAY))
        assertEquals(0, calendar.get(Calendar.MINUTE))
    }

    @Test
    fun predownloadAlwaysComesBeforeLaunch() {
        assertEquals(true, Targets.PREDOWNLOAD < Targets.LAUNCH)
    }

    @Test
    fun countdownUsesFourSeparateUnits() {
        val parts = CountdownTime.fromRemainingMillis(1L * 86_400_000L + 2L * 3_600_000L + 3L * 60_000L + 4_000L)
        assertEquals(1L, parts.days)
        assertEquals(2L, parts.hours)
        assertEquals(3L, parts.minutes)
        assertEquals(4L, parts.seconds)
    }

    @Test
    fun positiveFractionOfASecondRoundsUpUntilTarget() {
        assertEquals(1L, CountdownTime.fromRemainingMillis(1L).seconds)
        assertEquals(1L, CountdownTime.fromRemainingMillis(999L).seconds)
        assertEquals(0L, CountdownTime.fromRemainingMillis(0L).seconds)
        assertEquals(0L, CountdownTime.fromRemainingMillis(-1L).seconds)
    }

    @Test
    fun twoDigitFormatterPadsOnlyValuesBelowTen() {
        assertEquals("00", Fmt.two(0))
        assertEquals("09", Fmt.two(9))
        assertEquals("10", Fmt.two(10))
        assertEquals("123", Fmt.two(123))
    }
}
