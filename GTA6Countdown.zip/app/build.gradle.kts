plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.gta6.countdown"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.gta6.countdown"
        minSdk = 24
        targetSdk = 36
        versionCode = 6
        versionName = "3.2.1"
    }

    buildTypes {
        debug {
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    jvmToolchain(17)
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}


dependencies {
    testImplementation("junit:junit:4.13.2")
}
