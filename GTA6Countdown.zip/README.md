# GTA VI Countdown · v3.2

Aplicación Android ligera para consultar únicamente las dos cuentas atrás principales:

- **Predescarga:** 10 de noviembre de 2026 a las 00:00, hora peninsular española (`Europe/Madrid`).
- **Lanzamiento:** 19 de noviembre de 2026 a las 00:00, hora peninsular española (`Europe/Madrid`).

## Interfaz y rendimiento

- Pantalla principal estática, con las dos cuentas atrás como contenido central.
- Sin fondo animado, efectos de entrada, parallax, sensor de inclinación, fuegos artificiales ni animación de cifras.
- Actualización de la pantalla una vez por segundo y solo cambia los textos cuyo valor haya variado.
- El temporizador se detiene al salir de la aplicación y se reanuda al volver.
- Redondeo al segundo visible para evitar mostrar `00` antes de alcanzar la fecha objetivo.
- Widget grande con predescarga y lanzamiento; widget compacto con lanzamiento.
- Los widgets usan `Chronometer` para segundos y alarmas puntuales para actualizar días y horas, evitando refrescos completos cada segundo.

## Compilación

El workflow `.github/workflows/build.yml` usa Java 17, Gradle 8.11.1 y Android SDK 36. Ejecuta las pruebas unitarias, compila el APK y verifica su firma. El archivo aparece en **Actions → ejecución completada → Artifacts** como `GTA6Countdown-v3.2`.

## Fechas

Las fechas se configuran en `app/src/main/java/com/gta6/countdown/Targets.kt` y usan la zona horaria `Europe/Madrid`.

Proyecto de fans, no oficial y no afiliado a Rockstar Games ni Take-Two.
