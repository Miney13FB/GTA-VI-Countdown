# GTA VI Countdown 3.2.1

Versión minimalista: la pantalla principal se centra en los contadores de predescarga y lanzamiento.

## Correcciones de esta versión

- Corregido el error de compilación Kotlin en `MainActivity`: `ScrollView` expone `isFillViewport`, no `fillViewport`.
- Actualizado el identificador de versión a 3.2.1 (versionCode 6).
- Se mantienen los dos contadores, la hora Europe/Madrid y los widgets.

## Fechas

- Predescarga: 10 de noviembre de 2026 a las 00:00 (Europe/Madrid).
- Lanzamiento: 19 de noviembre de 2026 a las 00:00 (Europe/Madrid).

## Compilación

Desde la raíz del proyecto Android: `gradle testDebugUnitTest assembleDebug`.

El APK de depuración se genera en `app/build/outputs/apk/debug/`.
